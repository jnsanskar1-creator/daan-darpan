# 🗄️ Database Backup & Restore Guide

## Overview

The दान-दर्पण application includes comprehensive database backup and restore functionality to ensure data safety and easy deployment.

## Quick Commands

```bash
# Create backup
./scripts/backup-database.sh

# Restore latest backup
./scripts/restore-database.sh latest

# Restore specific backup
./scripts/restore-database.sh database-backups/daan_darpan_backup_20250817_120000.sql.gz

# Create sample data (for testing)
./scripts/create-sample-data.sh
```

## Backup System Features

### 1. Automated Backup Creation
- **Complete Data**: All tables, sequences, and relationships
- **Compressed Storage**: Automatic gzip compression
- **Timestamped Files**: Format: `daan_darpan_backup_YYYYMMDD_HHMMSS.sql.gz`
- **Latest Symlink**: Always points to most recent backup

### 2. Safe Restoration
- **Confirmation Prompts**: Prevents accidental data loss
- **Application Shutdown**: Automatically stops running processes
- **Clean Import**: Drops existing data before restore
- **Error Handling**: Stops on any SQL errors

### 3. Sample Data Generation
- **Pre-configured Users**: Admin, operators, viewers, and sample members
- **Financial Records**: Boli entries, payments, expenses, advance payments
- **Test Environment**: Perfect for development and training

## File Structure

```
database-backups/
├── daan_darpan_backup_20250817_120000.sql.gz
├── daan_darpan_backup_20250817_140000.sql.gz
├── latest_backup.sql.gz -> daan_darpan_backup_20250817_140000.sql.gz
└── restoration-logs/
```

## Restoration Steps for New Installation

### 1. Fresh Installation with Sample Data

```bash
# After extracting tar.gz and setting up PostgreSQL
cd ~/Desktop/daan-darpan-local

# Install dependencies
npm install

# Setup database schema
npm run db:push

# Create sample data for testing
chmod +x scripts/create-sample-data.sh
./scripts/create-sample-data.sh

# Start application
npm run dev
```

### 2. Restoration from Production Backup

```bash
# After extracting tar.gz and setting up PostgreSQL
cd ~/Desktop/daan-darpan-local

# Install dependencies
npm install

# Place your backup file in database-backups/ directory
mkdir -p database-backups
cp /path/to/your/backup.sql.gz database-backups/

# Restore database
chmod +x scripts/restore-database.sh
./scripts/restore-database.sh database-backups/your-backup.sql.gz

# Start application
npm run dev
```

### 3. Regular Backup Creation

```bash
# Create backup (run daily/weekly)
chmod +x scripts/backup-database.sh
./scripts/backup-database.sh

# Output will be in database-backups/ directory
```

## Backup File Contents

Each backup includes:

### Core Tables
- `users` - All user accounts and roles
- `boli_entries` - Auction/bid entries with payment tracking
- `boli_payments` - Individual payment records
- `advance_payments` - Prepaid amounts
- `expense_entries` - Temple expenses with receipts
- `dravya_entries` - Spiritual donations (separate system)
- `previous_outstanding_records` - Historical debt tracking

### Configuration Tables
- `corpus_settings` - Temple corpus/capital amount
- `receipt_counter` - Auto-incrementing receipt numbers
- `transaction_logs` - Complete audit trail

### File System
- Upload files in `uploads/` directory need separate backup
- Configuration files (`.env`) should be backed up separately

## Production Deployment Workflow

### Initial Setup
1. Extract `daan-darpan-local-v1.0.tar.gz`
2. Run `./setup.sh` for basic configuration
3. Configure PostgreSQL with `setup_database.sql`
4. Edit `.env` with production database credentials
5. Choose restoration method:
   - **New Installation**: Use `./scripts/create-sample-data.sh`
   - **Data Migration**: Use `./scripts/restore-database.sh your-backup.sql.gz`

### Regular Maintenance
1. **Daily Backups**: Set up cron job for `./scripts/backup-database.sh`
2. **Weekly Testing**: Verify backup integrity by restoring to test environment
3. **File Backups**: Separately backup `uploads/` directory and `.env` file

## Sample Data Details

The sample data includes:

### Users (Password: admin123)
- **admin** - Full administrative access
- **operator1** - Operator role access
- **viewer1** - Read-only access
- **ramesh_ji** - Sample temple member
- **sunita_devi** - Sample temple member

### Financial Data
- **Corpus**: ₹139,084 initial temple capital
- **Boli Entries**: 4 sample entries with various payment statuses
- **Payments**: Mix of cash, UPI payments with proper receipt numbers
- **Expenses**: Temple operational expenses with proper documentation
- **Advance Payments**: Sample prepaid amounts

### System Configuration
- **Receipt Counter**: Starting from SPDJMSJ000001
- **Transaction Logs**: Complete audit trail for all sample transactions

## Troubleshooting

### Common Issues

1. **Permission Denied**
   ```bash
   chmod +x scripts/*.sh
   ```

2. **PostgreSQL Connection Error**
   ```bash
   # Check if PostgreSQL is running
   sudo systemctl status postgresql
   
   # Check credentials in .env file
   cat .env | grep PG
   ```

3. **Backup File Not Found**
   ```bash
   # List available backups
   ls -la database-backups/
   
   # Use absolute path
   ./scripts/restore-database.sh /full/path/to/backup.sql.gz
   ```

4. **Application Still Running**
   ```bash
   # Manually stop processes
   pkill -f "tsx server/index.ts"
   pkill -f "node dist/index.js"
   ```

## Security Considerations

1. **Backup Encryption**: For production, encrypt backup files
2. **Access Control**: Restrict access to backup files (chmod 600)
3. **Regular Testing**: Test restore procedures monthly
4. **Off-site Storage**: Store backups in multiple locations
5. **Retention Policy**: Keep backups for at least 90 days

---

**Note**: This backup system is designed specifically for the local PostgreSQL deployment and maintains full compatibility with the दान-दर्पण application structure.