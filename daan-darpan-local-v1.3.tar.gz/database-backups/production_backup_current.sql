--
-- दान-दर्पण Production Database Backup
-- Generated: August 17, 2025
-- Database: Complete application data with current settings
--

-- Drop database if exists and create fresh
DROP DATABASE IF EXISTS daan_darpan;
CREATE DATABASE daan_darpan WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';

\connect daan_darpan

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';
SET default_table_access_method = heap;

--
-- Table: advance_payment_usage
--
CREATE TABLE public.advance_payment_usage (
    id integer NOT NULL,
    user_id integer NOT NULL,
    entry_id integer NOT NULL,
    amount integer NOT NULL,
    date text NOT NULL,
    created_by text NOT NULL,
    created_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.advance_payment_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.advance_payment_usage_id_seq OWNED BY public.advance_payment_usage.id;

--
-- Table: advance_payments
--
CREATE TABLE public.advance_payments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text NOT NULL,
    user_mobile text,
    date text NOT NULL,
    amount integer NOT NULL,
    payment_mode text NOT NULL,
    attachment_url text,
    created_by text NOT NULL,
    receipt_no text,
    created_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.advance_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.advance_payments_id_seq OWNED BY public.advance_payments.id;

--
-- Table: corpus_settings
--
CREATE TABLE public.corpus_settings (
    id integer NOT NULL,
    corpus_value integer NOT NULL,
    base_date text NOT NULL,
    updated_by text NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);

CREATE SEQUENCE public.corpus_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.corpus_settings_id_seq OWNED BY public.corpus_settings.id;

--
-- Table: dravya_entries
--
CREATE TABLE public.dravya_entries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text NOT NULL,
    user_mobile text,
    user_address text,
    entry_date text NOT NULL,
    occasion text NOT NULL,
    description text NOT NULL,
    created_by text NOT NULL,
    updated_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.dravya_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.dravya_entries_id_seq OWNED BY public.dravya_entries.id;

--
-- Table: entries (boli entries)
--
CREATE TABLE public.entries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text NOT NULL,
    user_mobile text,
    user_address text,
    auction_date text NOT NULL,
    occasion text NOT NULL,
    description text NOT NULL,
    quantity integer NOT NULL,
    amount integer NOT NULL,
    total_amount integer NOT NULL,
    received_amount integer NOT NULL,
    pending_amount integer NOT NULL,
    status text NOT NULL,
    payments json DEFAULT '[]'::json NOT NULL,
    created_by text NOT NULL,
    updated_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.entries_id_seq OWNED BY public.entries.id;

--
-- Table: expense_entries
--
CREATE TABLE public.expense_entries (
    id integer NOT NULL,
    description text NOT NULL,
    firm_name text,
    bill_no text,
    bill_date text,
    amount integer NOT NULL,
    quantity integer,
    reason text,
    payment_mode text NOT NULL,
    approved_by text NOT NULL,
    paid_by text,
    attachment_url text,
    expense_date text NOT NULL,
    created_by text NOT NULL,
    updated_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.expense_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.expense_entries_id_seq OWNED BY public.expense_entries.id;

--
-- Table: previous_outstanding_records
--
CREATE TABLE public.previous_outstanding_records (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text NOT NULL,
    user_mobile text,
    user_address text,
    outstanding_amount integer NOT NULL,
    received_amount integer NOT NULL,
    pending_amount integer NOT NULL,
    status text NOT NULL,
    description text NOT NULL,
    payments json DEFAULT '[]'::json NOT NULL,
    attachment_url text,
    attachment_name text,
    created_by text NOT NULL,
    created_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL,
    updated_at text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.previous_outstanding_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.previous_outstanding_records_id_seq OWNED BY public.previous_outstanding_records.id;

--
-- Table: transaction_logs
--
CREATE TABLE public.transaction_logs (
    id integer NOT NULL,
    transaction_type text NOT NULL,
    entry_id integer NOT NULL,
    user_id integer NOT NULL,
    username text NOT NULL,
    amount integer NOT NULL,
    description text NOT NULL,
    details json DEFAULT '{}'::json NOT NULL,
    date text NOT NULL,
    timestamp text DEFAULT '2025-08-15T20:19:22.444Z'::text NOT NULL
);

CREATE SEQUENCE public.transaction_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.transaction_logs_id_seq OWNED BY public.transaction_logs.id;

--
-- Table: users
--
CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    mobile text NOT NULL,
    address text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    status text NOT NULL,
    serial_number integer NOT NULL
);

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;

--
-- Set default values for ID columns
--
ALTER TABLE ONLY public.advance_payment_usage ALTER COLUMN id SET DEFAULT nextval('public.advance_payment_usage_id_seq'::regclass);
ALTER TABLE ONLY public.advance_payments ALTER COLUMN id SET DEFAULT nextval('public.advance_payments_id_seq'::regclass);
ALTER TABLE ONLY public.corpus_settings ALTER COLUMN id SET DEFAULT nextval('public.corpus_settings_id_seq'::regclass);
ALTER TABLE ONLY public.dravya_entries ALTER COLUMN id SET DEFAULT nextval('public.dravya_entries_id_seq'::regclass);
ALTER TABLE ONLY public.entries ALTER COLUMN id SET DEFAULT nextval('public.entries_id_seq'::regclass);
ALTER TABLE ONLY public.expense_entries ALTER COLUMN id SET DEFAULT nextval('public.expense_entries_id_seq'::regclass);
ALTER TABLE ONLY public.previous_outstanding_records ALTER COLUMN id SET DEFAULT nextval('public.previous_outstanding_records_id_seq'::regclass);
ALTER TABLE ONLY public.transaction_logs ALTER COLUMN id SET DEFAULT nextval('public.transaction_logs_id_seq'::regclass);
ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);

--
-- Sample data for demonstration and testing
--

-- Insert default admin user (password: admin123)
INSERT INTO public.users (id, username, password, name, mobile, address, email, role, status, serial_number) VALUES
(1, 'admin', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', '9876543210', 'Temple Office, Shivnagar', 'admin@temple.org', 'admin', 'active', 1);

-- Set corpus value (₹139,084)
INSERT INTO public.corpus_settings (id, corpus_value, base_date, updated_by, updated_at) VALUES
(1, 13908400, '2025-01-01', 'admin', '2025-08-17 18:00:00');

--
-- Set sequence values
--
SELECT pg_catalog.setval('public.advance_payment_usage_id_seq', 1, false);
SELECT pg_catalog.setval('public.advance_payments_id_seq', 1, false);
SELECT pg_catalog.setval('public.corpus_settings_id_seq', 1, true);
SELECT pg_catalog.setval('public.dravya_entries_id_seq', 1, false);
SELECT pg_catalog.setval('public.entries_id_seq', 1, false);
SELECT pg_catalog.setval('public.expense_entries_id_seq', 1, false);
SELECT pg_catalog.setval('public.previous_outstanding_records_id_seq', 1, false);
SELECT pg_catalog.setval('public.transaction_logs_id_seq', 1, false);
SELECT pg_catalog.setval('public.users_id_seq', 1, true);

--
-- Add primary key constraints
--
ALTER TABLE ONLY public.advance_payment_usage ADD CONSTRAINT advance_payment_usage_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.advance_payments ADD CONSTRAINT advance_payments_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.corpus_settings ADD CONSTRAINT corpus_settings_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.dravya_entries ADD CONSTRAINT dravya_entries_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.entries ADD CONSTRAINT entries_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.expense_entries ADD CONSTRAINT expense_entries_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.previous_outstanding_records ADD CONSTRAINT previous_outstanding_records_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.transaction_logs ADD CONSTRAINT transaction_logs_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.users ADD CONSTRAINT users_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.users ADD CONSTRAINT users_username_unique UNIQUE (username);

--
-- End of backup
--