import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, Plus, X, Eye } from "lucide-react";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

interface PreviousOutstanding {
  id: number;
  userId: number;
  userName: string;
  userMobile: string;
  userAddress: string;
  outstandingAmount: number;
  receivedAmount: number;
  pendingAmount: number;
  status: 'pending' | 'partial' | 'full';
  payments: PaymentRecord[];
  description: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface PaymentRecord {
  date: string;
  amount: number;
  mode: string;
  fileUrl?: string;
  receiptNo?: string;
  updatedBy?: string;
}

export default function PreviousOutstanding() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState("");
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  
  // Check if user has permission to view this page
  if (user?.role === 'viewer') {
    return (
      <div className="p-4">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <h2 className="text-lg font-semibold text-red-800 mb-2">Access Denied</h2>
          <p className="text-red-600">You don't have permission to view previous outstanding records.</p>
        </div>
      </div>
    );
  }

  // Fetch previous outstanding records with date range query params
  const queryParams = new URLSearchParams();
  if (startDate) {
    queryParams.append('startDate', startDate.toISOString().split('T')[0]);
  }
  if (endDate) {
    queryParams.append('endDate', endDate.toISOString().split('T')[0]);
  }

  const { data: records, isLoading } = useQuery<PreviousOutstanding[]>({
    queryKey: ['/api/previous-outstanding', queryParams.toString()],
    staleTime: 0,
    gcTime: 0,
  });

  // Apply filters
  const filteredRecords = useMemo(() => {
    return (records || []).filter(record => {
      const matchesSearch = !searchTerm || 
        record.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.userMobile?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.createdBy.toLowerCase().includes(searchTerm.toLowerCase());
      
      const recordDate = new Date(record.createdAt);
      const matchesDateRange = (!startDate || recordDate >= startDate) && 
                              (!endDate || recordDate <= endDate);
      
      return matchesSearch && matchesDateRange;
    });
  }, [records, searchTerm, startDate, endDate]);

  const clearFilters = () => {
    setSearchTerm("");
    setStartDate(null);
    setEndDate(null);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN');
  };

  const formatAmount = (amount: number) => {
    return amount.toLocaleString();
  };

  const getStatusBadge = (status: string, pendingAmount: number) => {
    if (status === 'full' || pendingAmount <= 0) {
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Payment Completed</Badge>;
    } else if (status === 'partial' && pendingAmount > 0) {
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Partially Paid</Badge>;
    } else {
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Payment Pending</Badge>;
    }
  };

  const totalAmount = filteredRecords.reduce((sum, record) => sum + record.outstandingAmount, 0);

  return (
    <div className="space-y-6 p-4">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Previous Outstanding Records</h1>
          <p className="text-muted-foreground">
            Historical outstanding amounts from old system
          </p>
        </div>
        {(user?.role === 'admin' || user?.role === 'operator') && (
          <Button onClick={() => setLocation('/previous-outstanding/new')}>
            <Plus className="h-4 w-4 mr-2" />
            Add Record
          </Button>
        )}
      </div>

      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{filteredRecords.length}</div>
              <p className="text-sm text-muted-foreground">Total Records</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-600">₹{totalAmount.toLocaleString()}</div>
              <p className="text-sm text-muted-foreground">Total Outstanding</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                ₹{filteredRecords.reduce((sum, record) => sum + (record.receivedAmount || 0), 0).toLocaleString()}
              </div>
              <p className="text-sm text-muted-foreground">Total Received</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                ₹{filteredRecords.reduce((sum, record) => sum + (record.pendingAmount || record.outstandingAmount), 0).toLocaleString()}
              </div>
              <p className="text-sm text-muted-foreground">Total Pending</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Filters</CardTitle>
            <Button variant="outline" size="sm" onClick={clearFilters}>
              <X className="h-4 w-4 mr-2" />
              Clear Filters
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Search</label>
              <Input
                placeholder="Search by name, mobile, description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">From Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={startDate || undefined}
                    onSelect={(date) => setStartDate(date || null)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">To Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={endDate || undefined}
                    onSelect={(date) => setEndDate(date || null)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Records Table */}
      <Card>
        <CardHeader>
          <CardTitle>Records ({filteredRecords.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : filteredRecords.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {records?.length === 0 ? "No previous outstanding records found." : "No records match your search criteria."}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User Details</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Payment Status</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{record.userName}</div>
                          <div className="text-sm text-muted-foreground">{record.userMobile}</div>
                          <div className="text-xs text-muted-foreground">{record.userAddress}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">₹{formatAmount(record.outstandingAmount)}</div>
                        {(record.receivedAmount || 0) > 0 && (
                          <div className="text-sm text-green-600">Received: ₹{formatAmount(record.receivedAmount || 0)}</div>
                        )}
                        {(record.pendingAmount || record.outstandingAmount) > 0 && (
                          <div className="text-sm text-red-600">Pending: ₹{formatAmount(record.pendingAmount || record.outstandingAmount)}</div>
                        )}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(record.status || 'pending', record.pendingAmount || record.outstandingAmount)}
                      </TableCell>
                      <TableCell>{record.description}</TableCell>
                      <TableCell>
                        <div>
                          <div className="text-sm">{formatDate(record.createdAt)}</div>
                          <div className="text-xs text-muted-foreground">by {record.createdBy}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setLocation(`/previous-outstanding/${record.id}/details`)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}