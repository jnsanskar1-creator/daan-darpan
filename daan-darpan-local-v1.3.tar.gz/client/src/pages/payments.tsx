import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { PaymentMode, type Entry } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import DatePicker from "react-datepicker";
import { useToast } from "@/hooks/use-toast";
import { HindiReceipt } from "@/components/hindi-receipt";
import "react-datepicker/dist/react-datepicker.css";

// Helper function to format dates from ISO string to readable format
const formatDate = (isoString: string) => {
  if (!isoString) return "N/A";
  const date = new Date(isoString);
  return date.toLocaleDateString();
};

// WhatsApp notification function for payments
const sendWhatsAppPaymentNotification = (payment: any) => {
  // Clean phone number (remove spaces, dashes, parentheses)
  const cleanNumber = payment.userMobile?.replace(/[\s\-\(\)]/g, '');
  
  if (!cleanNumber) {
    alert('No phone number available for this user');
    return;
  }
  
  // Format phone number for WhatsApp (ensure it starts with country code)
  let formattedNumber = cleanNumber;
  if (!formattedNumber.startsWith('91') && formattedNumber.length === 10) {
    formattedNumber = '91' + formattedNumber; // Add India country code
  }
  
  // Calculate payment amounts breakdown
  const paymentAmounts = payment.entry?.payments?.map((p: any) => `₹${p.amount}`) || [];
  const paymentAmountsText = paymentAmounts.join(' + ');
  
  // Calculate receipt numbers breakdown
  const receiptNumbers = payment.entry?.payments?.map((p: any) => p.receiptNo).filter((r: any) => r) || [];
  const receiptNumbersText = receiptNumbers.join(' + ');

  // Create payment confirmation message with simple text markers
  const message = 
    `शिवनगर जैन मंदिर के अग्रणी सदस्य आपका भुगतान सफलतापूर्वक प्राप्त हुआ है:\n\n` +
    `📝 विवरण: ${payment.entryDescription}\n` +
    `🗓️ भुगतान दिनांक: ${formatDate(payment.date)}\n` +
    `📅 बोली दिनांक: ${formatDate(payment.entryBoliDate) || 'N/A'}\n` +
    `💰 कुल राशि: ₹${payment.entry?.totalAmount?.toLocaleString() || 'N/A'}\n` +
    `✅ प्राप्त: ${paymentAmountsText}\n` +
    `⏳ शेष: ₹${payment.entry?.pendingAmount?.toLocaleString() || 'N/A'}\n` +
    `💳 भुगतान माध्यम: ${payment.mode}\n` +
    `🧾 रसीद नंबर: ${receiptNumbersText || 'N/A'}\n\n` +
    `आपके सहयोग के लिए धन्यवाद! 🙏`;
  
  // Create WhatsApp URL using different encoding approach
  const whatsappUrl = `https://api.whatsapp.com/send?phone=${formattedNumber}&text=${encodeURIComponent(message)}`;
  
  // Open WhatsApp in new tab/window
  window.open(whatsappUrl, '_blank');
};

export default function Payments() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [dateRange, setDateRange] = useState<[Date | null, Date | null]>([null, null]);
  const [filterByMode, setFilterByMode] = useState("");
  
  // Hindi Receipt state
  const [hindiReceiptState, setHindiReceiptState] = useState<{
    isOpen: boolean;
    entry: Entry | null;
    payment: any | null;
    paymentIndex: number;
  }>({
    isOpen: false,
    entry: null,
    payment: null,
    paymentIndex: -1
  });
  
  // Fetch all entries to extract payments
  const { data: entries, isLoading } = useQuery<Entry[]>({
    queryKey: ['/api/entries']
  });
  
  // Flatten all payments from all entries
  const allPayments = entries?.flatMap(entry => entry.payments.map((payment, paymentIndex) => ({
    ...payment,
    entryId: entry.id,
    paymentIndex,
    entryDescription: entry.description,
    userName: entry.userName,
    userMobile: entry.userMobile,
    entry: entry // Add entry reference for Hindi receipt
  }))) || [];
  
  // Sort all payments by date (most recent first)
  const sortedPayments = [...allPayments].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  // Apply filters
  const filteredPayments = sortedPayments.filter(payment => {
    // Search filter (case insensitive)
    const searchMatches = !searchQuery || 
      payment.entryDescription?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.userName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.userMobile?.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Date range filter
    let dateMatches = true;
    if (dateRange[0] || dateRange[1]) {
      const paymentDate = new Date(payment.date);
      
      if (dateRange[0]) {
        // Start date is set, check if payment date is on or after it
        const startDate = new Date(dateRange[0]);
        startDate.setHours(0, 0, 0, 0);
        if (paymentDate < startDate) {
          dateMatches = false;
        }
      }
      
      if (dateRange[1]) {
        // End date is set, check if payment date is on or before it
        const endDate = new Date(dateRange[1]);
        // Set to end of day to include the full day
        endDate.setHours(23, 59, 59, 999);
        if (paymentDate > endDate) {
          dateMatches = false;
        }
      }
    }
    
    // Mode filter
    const modeMatches = !filterByMode || filterByMode === 'all' || payment.mode === filterByMode;
    
    return searchMatches && dateMatches && modeMatches;
  });

  // Function to delete a payment
  const handleDeletePayment = async (entryId: number, paymentIndex: number) => {
    if (confirm("Are you sure you want to delete this payment record? This will be logged as a credit entry.")) {
      try {
        // Make API call to delete the payment
        const response = await fetch(`/api/entries/${entryId}/payments/${paymentIndex}`, { 
          method: 'DELETE' 
        });
        
        if (!response.ok) {
          throw new Error('Failed to delete payment');
        }
        
        toast({
          title: "Payment Deleted",
          description: "The payment record has been deleted and logged as a credit."
        });
        
        // Refresh all relevant data
        queryClient.invalidateQueries({ queryKey: ['/api/entries'] });
        queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
        queryClient.invalidateQueries({ queryKey: ['/api/transaction-logs'] });
      } catch (error) {
        console.error('Error deleting payment:', error);
        toast({
          title: "Error",
          description: "Failed to delete payment record",
          variant: "destructive"
        });
      }
    }
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading payments...</div>;
  }

  return (
    <div className="flex-grow p-4 pb-20">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-medium">All Boli Payments</h1>
        <p className="text-sm text-neutral-500">View all recorded boli payments</p>
      </div>
      
      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Search */}
          <div>
            <Label htmlFor="search" className="mb-1 block">Search</Label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <span className="material-icons text-neutral-500 text-lg">search</span>
              </span>
              <Input 
                id="search"
                placeholder="Search by description or user" 
                className="pl-10 pr-4 py-2"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          {/* Date Range Filter */}
          <div>
            <Label htmlFor="dateFilter" className="mb-1 block">Date Range</Label>
            <div className="datepicker-container w-full">
              <DatePicker
                selectsRange={true}
                startDate={dateRange[0]}
                endDate={dateRange[1]}
                onChange={(update) => {
                  setDateRange(update);
                }}
                isClearable={true}
                placeholderText="Select date range"
                className="w-full border rounded-md p-2 text-sm"
                dateFormat="MMM d, yyyy"
                monthsShown={2}
                showMonthYearPicker={false}
                calendarStartDay={1}
                fixedHeight
                renderMonthContent={(month, shortMonth) => <div>{shortMonth}</div>}
                renderCustomHeader={({
                  date,
                  decreaseMonth,
                  increaseMonth,
                  prevMonthButtonDisabled,
                  nextMonthButtonDisabled,
                }) => (
                  <div className="flex items-center justify-between px-2 py-2">
                    <button
                      onClick={decreaseMonth}
                      disabled={prevMonthButtonDisabled}
                      type="button"
                      className="p-1 rounded-full hover:bg-neutral-100"
                    >
                      <span className="material-icons">chevron_left</span>
                    </button>
                    <div className="text-lg font-medium">
                      {date.toLocaleDateString('en-US', {
                        month: 'long',
                        year: 'numeric',
                      })}
                    </div>
                    <button
                      onClick={increaseMonth}
                      disabled={nextMonthButtonDisabled}
                      type="button"
                      className="p-1 rounded-full hover:bg-neutral-100"
                    >
                      <span className="material-icons">chevron_right</span>
                    </button>
                  </div>
                )}
              />
            </div>
          </div>
          
          {/* Payment Mode Filter */}
          <div>
            <Label htmlFor="modeFilter" className="mb-1 block">Payment Mode</Label>
            <Select
              value={filterByMode}
              onValueChange={setFilterByMode}
            >
              <SelectTrigger id="modeFilter">
                <SelectValue placeholder="All payment modes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All payment modes</SelectItem>
                <SelectItem value={PaymentMode.CASH}>Cash</SelectItem>
                <SelectItem value={PaymentMode.UPI}>UPI</SelectItem>
                <SelectItem value={PaymentMode.NETBANKING}>Net Banking</SelectItem>
                <SelectItem value={PaymentMode.CHEQUE}>Cheque</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      
      {/* Payment list - desktop view */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden hidden md:block">
        <table className="w-full">
          <thead className="bg-neutral-100 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">Date</th>
              <th className="px-4 py-3 font-medium">Receipt No.</th>
              <th className="px-4 py-3 font-medium">Description</th>
              <th className="px-4 py-3 font-medium">User</th>
              <th className="px-4 py-3 font-medium">Amount</th>
              <th className="px-4 py-3 font-medium">Mode</th>
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPayments.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-4 text-center text-neutral-500">
                  No payment records found
                </td>
              </tr>
            ) : (
              filteredPayments.map((payment, index) => (
                <tr key={`${payment.entryId}-${index}`} className="border-t border-neutral-200">
                  <td className="px-4 py-3">{formatDate(payment.date)}</td>
                  <td className="px-4 py-3">
                    <span className="text-sm font-medium">
                      {payment.receiptNo || 'N/A'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-blue-600 font-medium"
                      onClick={() => setLocation(`/entries/${payment.entryId}`)}
                    >
                      {payment.entryDescription}
                    </Button>
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <div>{payment.userName}</div>
                      {payment.userMobile && (
                        <div className="text-xs text-neutral-500">📱 {payment.userMobile}</div>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-medium text-green-500">
                    ₹{payment.amount.toLocaleString()}
                  </td>
                  <td className="px-4 py-3">{payment.mode}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      {/* Hindi Receipt Button */}
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-blue-600"
                        onClick={() => {
                          setHindiReceiptState({
                            isOpen: true,
                            entry: payment.entry,
                            payment: payment,
                            paymentIndex: payment.paymentIndex
                          });
                        }}
                      >
                        Hindi Receipt
                      </Button>
                      
                      {/* WhatsApp Button */}
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-green-600"
                        onClick={() => sendWhatsAppPaymentNotification(payment)}
                      >
                        WhatsApp
                      </Button>
                      
                      {/* View Payment Screenshot Button (if available) */}
                      {payment.fileUrl && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-blue-600"
                            >
                              View Upload
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-3xl">
                            <DialogHeader>
                              <DialogTitle>Payment Upload</DialogTitle>
                            </DialogHeader>
                            <div className="flex justify-center p-2">
                              <img 
                                src={payment.fileUrl}
                                alt="Payment upload" 
                                className="max-h-[70vh] object-contain"
                              />
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                      
                      {/* Admin Controls */}
                      {user?.role === 'admin' && (
                        <>
                          {/* Edit payment functionality has been disabled */}
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-red-600"
                            onClick={() => handleDeletePayment(payment.entryId, payment.paymentIndex)}
                          >
                            <span className="material-icons text-sm">delete</span>
                            <span className="sr-only">Delete</span>
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      {/* Payment list - mobile view */}
      <div className="md:hidden space-y-4">
        {filteredPayments.length === 0 ? (
          <div className="bg-white p-4 rounded-lg shadow text-center text-neutral-500">
            No payment records found
          </div>
        ) : (
          filteredPayments.map((payment, index) => (
            <Card key={`${payment.entryId}-${index}`} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="bg-primary text-white p-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">{payment.entryDescription}</h3>
                      <p className="text-sm opacity-90">{payment.userName}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">₹{payment.amount.toLocaleString()}</div>
                      <div className="text-xs">{formatDate(payment.date)}</div>
                    </div>
                  </div>
                </div>
                
                <div className="p-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-neutral-500">Receipt No:</p>
                      <p className="font-medium">{payment.receiptNo || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Mode:</p>
                      <p className="font-medium">{payment.mode}</p>
                    </div>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t flex justify-between">
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-blue-600 text-sm"
                      onClick={() => setLocation(`/entries/${payment.entryId}`)}
                    >
                      View Entry
                    </Button>
                    
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-blue-600 text-xs"
                        onClick={() => {
                          setHindiReceiptState({
                            isOpen: true,
                            entry: payment.entry,
                            payment: payment,
                            paymentIndex: payment.paymentIndex
                          });
                        }}
                      >
                        Hindi Receipt
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-green-600 text-xs"
                        onClick={() => sendWhatsAppPaymentNotification(payment)}
                      >
                        WhatsApp
                      </Button>
                      
                      {payment.fileUrl && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="text-blue-600 text-xs"
                          onClick={() => {
                            // Open file view dialog
                          }}
                        >
                          Upload
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
      
      {/* Hindi Receipt Component */}
      {hindiReceiptState.isOpen && hindiReceiptState.entry && hindiReceiptState.payment && (
        <HindiReceipt
          entry={hindiReceiptState.entry}
          payment={hindiReceiptState.payment}
          paymentIndex={hindiReceiptState.paymentIndex}
          isOpen={hindiReceiptState.isOpen}
          onClose={() => setHindiReceiptState({
            isOpen: false,
            entry: null,
            payment: null,
            paymentIndex: -1
          })}
        />
      )}
    </div>
  );
}