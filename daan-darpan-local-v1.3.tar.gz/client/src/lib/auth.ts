import { queryClient } from "./queryClient";

export type AuthUser = {
  id: number;
  username: string;
  name: string;
  email: string;
  role: string;
  status?: string;
  mobile?: string;
  address?: string;
};

export async function logout() {
  try {
    await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "include",
    });
    queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
    
    // Force reload the page to clear any state and redirect to login
    window.location.href = "/";
    return true;
  } catch (error) {
    console.error("Logout failed:", error);
    return false;
  }
}
