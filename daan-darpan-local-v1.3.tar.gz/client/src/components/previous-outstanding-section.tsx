import { useQuery } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Eye } from "lucide-react";
import { useLocation } from "wouter";

interface PaymentRecord {
  date: string;
  amount: number;
  mode: string;
  fileUrl?: string;
  receiptNo?: string;
  updatedBy?: string;
}

interface PreviousOutstandingRecord {
  id: number;
  userId: number;
  userName: string;
  userMobile: string;
  userAddress: string;
  outstandingAmount: number;
  receivedAmount: number;
  pendingAmount: number;
  status: 'pending' | 'partial' | 'full';
  payments: PaymentRecord[];
  description: string;
  attachmentUrl?: string;
  attachmentName?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface PreviousOutstandingSectionProps {
  userId: number;
}

export function PreviousOutstandingSection({ userId }: PreviousOutstandingSectionProps) {
  const [, setLocation] = useLocation();
  
  // Fetch previous outstanding records for this user
  const { data: previousOutstandingRecords = [], isLoading } = useQuery<PreviousOutstandingRecord[]>({
    queryKey: [`/api/previous-outstanding?userId=${userId}`],
    enabled: !!userId,
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatAmount = (amountInRupees: number) => {
    return amountInRupees.toLocaleString('en-IN');
  };

  const handleViewAttachment = (attachmentUrl: string) => {
    window.open(attachmentUrl, '_blank');
  };

  const getStatusBadge = (status: string, pendingAmount: number) => {
    if (status === 'full' || pendingAmount <= 0) {
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Payment Completed</Badge>;
    } else if (status === 'partial' && pendingAmount > 0) {
      return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Partially Paid</Badge>;
    } else {
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Payment Pending</Badge>;
    }
  };

  if (isLoading) {
    return <div>Loading previous outstanding records...</div>;
  }

  if (previousOutstandingRecords.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        No previous outstanding records found for this user.
      </div>
    );
  }

  const totalOutstanding = previousOutstandingRecords.reduce(
    (sum, record) => sum + record.outstandingAmount, 
    0
  );

  const totalReceived = previousOutstandingRecords.reduce(
    (sum, record) => sum + (record.receivedAmount || 0), 
    0
  );

  const totalPending = previousOutstandingRecords.reduce(
    (sum, record) => sum + (record.pendingAmount || record.outstandingAmount), 
    0
  );

  return (
    <div className="space-y-4">
      {/* Enhanced Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
          <div>
            <h3 className="font-medium text-amber-800">Total Outstanding</h3>
            <p className="text-xs text-amber-600">Original amounts</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-amber-800">₹{formatAmount(totalOutstanding)}</p>
            <p className="text-xs text-amber-600">{previousOutstandingRecords.length} records</p>
          </div>
        </div>

        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
          <div>
            <h3 className="font-medium text-green-800">Total Received</h3>
            <p className="text-xs text-green-600">Payments made</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-green-800">₹{formatAmount(totalReceived)}</p>
            <p className="text-xs text-green-600">
              {totalOutstanding > 0 ? Math.round((totalReceived / totalOutstanding) * 100) : 0}% paid
            </p>
          </div>
        </div>

        <div className="p-4 bg-red-50 rounded-lg border border-red-200">
          <div>
            <h3 className="font-medium text-red-800">Total Pending</h3>
            <p className="text-xs text-red-600">Remaining balance</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-red-800">₹{formatAmount(totalPending)}</p>
            <p className="text-xs text-red-600">
              {totalOutstanding > 0 ? Math.round((totalPending / totalOutstanding) * 100) : 0}% remaining
            </p>
          </div>
        </div>
      </div>

      {/* Records Table */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Description</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Payment Status</TableHead>
              <TableHead>Date Added</TableHead>
              <TableHead>Added By</TableHead>
              <TableHead>Proof</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {previousOutstandingRecords.map((record) => (
              <TableRow key={record.id}>
                <TableCell className="font-medium">{record.description}</TableCell>
                <TableCell>
                  <div className="font-medium">₹{formatAmount(record.outstandingAmount)}</div>
                  {(record.receivedAmount || 0) > 0 && (
                    <div className="text-sm text-green-600">Received: ₹{formatAmount(record.receivedAmount || 0)}</div>
                  )}
                  {(record.pendingAmount || record.outstandingAmount) > 0 && (
                    <div className="text-sm text-red-600">Pending: ₹{formatAmount(record.pendingAmount || record.outstandingAmount)}</div>
                  )}
                </TableCell>
                <TableCell>
                  {getStatusBadge(record.status || 'pending', record.pendingAmount || record.outstandingAmount)}
                </TableCell>
                <TableCell>{formatDate(record.createdAt)}</TableCell>
                <TableCell>{record.createdBy}</TableCell>
                <TableCell>
                  {record.attachmentUrl ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewAttachment(record.attachmentUrl!)}
                    >
                      <FileText className="h-4 w-4 mr-1" />
                      View
                    </Button>
                  ) : (
                    <span className="text-muted-foreground text-sm">No attachment</span>
                  )}
                </TableCell>
                <TableCell>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setLocation(`/previous-outstanding/${record.id}/details`)}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    Details
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}