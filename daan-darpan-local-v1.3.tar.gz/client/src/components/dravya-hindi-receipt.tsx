import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface DravyaEntry {
  id: number;
  userId: number;
  userName: string;
  description: string;
  quantity: number;
  createdAt: string;
  userAddress?: string;
  userMobile?: string;
}

interface DravyaHindiReceiptProps {
  entry: DravyaEntry;
  receiptNo?: string;
}

export function DravyaHindiReceipt({ entry, receiptNo }: DravyaHindiReceiptProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [editableData, setEditableData] = useState({
    dharmanuyayi: entry.userName || "",
    address: entry.userAddress || "शिवनगर, जबलपुर (म.प्र.)",
    date: new Date().toLocaleDateString('hi-IN', { day: '2-digit', month: '2-digit', year: '2-digit' }).replace(/\//g, '/'),
    drayvaSankhya: (entry.quantity || 1).toString(),
    receiptNumber: receiptNo || `SPDJMSJ-${new Date().getFullYear()}-${String(entry.id).padStart(5, '0')}`
  });
  const { toast } = useToast();

  const formatDateDDMMYY = (date: string | Date) => {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = String(d.getFullYear()).slice(-2);
    return `${day}/${month}/${year}`;
  };

  const generateReceiptHTML = () => {
    const formattedUserName = editableData.dharmanuyayi || entry.userName;
    const hindiAddress = editableData.address;
    
    return `
      <!DOCTYPE html>
      <html lang="hi">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>दान रसीद - ${formattedUserName}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap');
            
            body {
              font-family: 'Noto Sans Devanagari', sans-serif;
              margin: 0;
              padding: 10px;
              background-color: #f5f5f5;
            }
            
            .receipt-container {
              max-width: 600px;
              margin: 0 auto;
              background: white;
              border: 2px solid #000;
              border-radius: 8px;
              padding: 0;
              box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            
            .receipt-header {
              text-align: center;
              border-bottom: 2px solid #000;
              padding: 20px;
              background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
              position: relative;
              min-height: 120px;
            }
            
            .temple-name {
              font-size: 24px;
              font-weight: 700;
              color: #d97706;
              margin: 10px 0 5px 0;
              text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
            }
            
            .temple-subtitle {
              font-size: 14px;
              color: #374151;
              margin: 5px 0;
              font-weight: 500;
            }
            
            .receipt-title {
              font-size: 20px;
              font-weight: 700;
              color: #1f2937;
              margin: 15px 0 5px 0;
              padding: 8px 16px;
              background: #fef3c7;
              border: 1px solid #f59e0b;
              border-radius: 4px;
              display: inline-block;
            }
            
            .receipt-body {
              padding: 20px;
            }
            
            .receipt-section {
              margin-bottom: 20px;
            }
            
            .receipt-row {
              display: flex;
              justify-content: space-between;
              margin-bottom: 12px;
              gap: 20px;
            }
            
            .left-item, .right-item {
              flex: 1;
              display: flex;
              align-items: baseline;
              gap: 8px;
            }
            
            .receipt-label {
              font-weight: 600;
              color: #6b7280;
              white-space: nowrap;
              min-width: fit-content;
            }
            
            .receipt-value {
              font-weight: 500;
              color: #1f2937;
              flex: 1;
              text-align: left;
            }
            
            .dravya-section {
              background: #fef3c7;
              border: 1px solid #f59e0b;
              border-radius: 6px;
              padding: 16px;
              margin: 20px 0;
              text-align: center;
            }
            
            .dravya-title {
              font-size: 18px;
              font-weight: 700;
              color: #92400e;
              margin-bottom: 8px;
            }
            
            .dravya-description {
              font-size: 16px;
              font-weight: 600;
              color: #1f2937;
              margin-bottom: 8px;
            }
            
            .dravya-quantity {
              font-size: 14px;
              color: #374151;
              font-style: italic;
            }
            
            .receipt-footer {
              border-top: 1px solid #e5e7eb;
              padding: 20px;
              text-align: center;
            }
            
            .signature-section {
              display: flex;
              justify-content: space-between;
              margin-top: 40px;
              padding-top: 20px;
            }
            
            .signature-box {
              text-align: center;
              flex: 1;
            }
            
            .signature-line {
              border-bottom: 1px solid #000;
              width: 150px;
              margin: 0 auto 10px auto;
            }
            
            .signature-label {
              font-size: 12px;
              color: #6b7280;
              font-weight: 500;
            }
            
            .footer-message {
              font-size: 14px;
              color: #6b7280;
              margin-top: 20px;
              font-style: italic;
            }
            
            @media print {
              body { 
                margin: 0; 
                padding: 10px; 
              }
              .receipt-container {
                border: 1px solid #000;
                page-break-inside: avoid;
              }
            }
          </style>
        </head>
        <body>
          <div class="receipt-container">
            <!-- Header -->
            <div class="receipt-header" style="position: relative;">
              <!-- Left Logo - Jain Symbol -->
              <div style="position: absolute; left: 15px; top: 15px;">
                <img src="/jain-symbol.png" 
                     alt="Jain Symbol" style="width: 60px; height: 60px; object-fit: contain;">
              </div>
              
              <!-- Right Logo - Temple Building -->
              <div style="position: absolute; right: 15px; top: 15px;">
                <img src="/temple-logo.png" 
                     alt="Temple Logo" style="width: 60px; height: 60px; object-fit: contain; border-radius: 50%;">
              </div>
              
              <!-- Center Text -->
              <div class="temple-name">शिवनगर जैन मंदिर समिति</div>
              <div class="temple-subtitle">शिवनगर, दमोह रोड, जबलपुर (म.प्र.)</div>
              <div class="receipt-title">द्रव्य दान रसीद</div>
            </div>
            
            <!-- Body -->
            <div class="receipt-body">
              <!-- Row 1: User Name and Address -->
              <div class="receipt-section">
                <div class="receipt-row">
                  <div class="left-item">
                    <span class="receipt-label">धर्मानुयायी:</span>
                    <span class="receipt-value">${formattedUserName}</span>
                  </div>
                  <div class="right-item">
                    <span class="receipt-label">पता:</span>
                    <span class="receipt-value">${hindiAddress}</span>
                  </div>
                </div>
              </div>
              
              <!-- Row 2: Receipt Number and Date -->
              <div class="receipt-section">
                <div class="receipt-row">
                  <div class="left-item">
                    <span class="receipt-label">अनुक्रमांक:</span>
                    <span class="receipt-value">${editableData.receiptNumber}</span>
                  </div>
                  <div class="right-item">
                    <span class="receipt-label">दिनांक:</span>
                    <span class="receipt-value">${editableData.date}</span>
                  </div>
                </div>
              </div>
              
              <!-- Dravya Section -->
              <div class="dravya-section">
                <div class="dravya-title">दान वस्तु</div>
                <div class="dravya-description">द्रव्य दान</div>
                <div class="dravya-quantity">मात्रा: ${editableData.drayvaSankhya}</div>
              </div>
            </div>
            
            <!-- Footer -->
            <div class="receipt-footer">
              <div class="signature-section">
                <div class="signature-box">
                  <div class="signature-line"></div>
                  <div class="signature-label">दाता के हस्ताक्षर</div>
                </div>
                <div class="signature-box">
                  <div class="signature-line"></div>
                  <div class="signature-label">हस्ताक्षर प्राधिकारी</div>
                </div>
              </div>
              
              <div class="footer-message">
                धन्यवाद! आपका सहयोग अमूल्य है।
              </div>
            </div>
          </div>
        </body>
      </html>
    `;
  };

  const handleSaveAndPrint = () => {
    const receiptHTML = generateReceiptHTML();
    
    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(receiptHTML);
      printWindow.document.close();
      
      // Wait for content to load, then print
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
        }, 100);
      };
      
      toast({
        title: "Success",
        description: "Receipt opened for printing"
      });
    } else {
      toast({
        title: "Error", 
        description: "Unable to open print window. Please check popup settings.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100">
          🧾 Hindi Receipt
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left side - Editable fields */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Edit Receipt Details</h3>
            
            <div>
              <Label htmlFor="dharmanuyayi">धर्मानुयायी (Editable)</Label>
              <Input
                id="dharmanuyayi"
                value={editableData.dharmanuyayi}
                onChange={(e) => setEditableData({...editableData, dharmanuyayi: e.target.value})}
                placeholder="Name"
              />
            </div>
            
            <div>
              <Label htmlFor="address">पता (Editable)</Label>
              <Textarea
                id="address"
                value={editableData.address}
                onChange={(e) => setEditableData({...editableData, address: e.target.value})}
                placeholder="Address"
                rows={2}
              />
            </div>
            
            <div>
              <Label htmlFor="date">दिनांक (Editable)</Label>
              <Input
                id="date"
                value={editableData.date}
                onChange={(e) => setEditableData({...editableData, date: e.target.value})}
                placeholder="DD/MM/YY"
              />
            </div>
            
            <div>
              <Label htmlFor="drayvaSankhya">द्रव्य संख्या (Editable)</Label>
              <Input
                id="drayvaSankhya"
                value={editableData.drayvaSankhya}
                onChange={(e) => setEditableData({...editableData, drayvaSankhya: e.target.value})}
                placeholder="Quantity"
              />
            </div>
            
            <div>
              <Label htmlFor="receiptNumber">Receipt Number (Editable)</Label>
              <Input
                id="receiptNumber"
                value={editableData.receiptNumber}
                onChange={(e) => setEditableData({...editableData, receiptNumber: e.target.value})}
                placeholder="Receipt Number"
              />
            </div>
          </div>
          
          {/* Right side - Preview */}
          <div className="border rounded-lg p-4 bg-gray-50">
            <h3 className="text-lg font-semibold mb-4">Receipt Preview</h3>
            <div 
              className="bg-white border rounded scale-75 origin-top-left"
              style={{ width: '133%', height: 'auto' }}
              dangerouslySetInnerHTML={{ __html: generateReceiptHTML() }}
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSaveAndPrint} className="bg-orange-600 hover:bg-orange-700">
            Save & Print Receipt
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}