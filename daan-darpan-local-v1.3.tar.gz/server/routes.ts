import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import csv from "csv-parser";
import { storage } from "./storage";
import { ZodError } from "zod";
import { eq, desc } from "drizzle-orm";
import { db, pool } from "./db";
import { 
  insertUserSchema, 
  insertEntrySchema,
  insertDravyaEntrySchema,
  insertExpenseEntrySchema,
  insertAdvancePaymentSchema,
  insertPreviousOutstandingRecordSchema,
  insertCorpusSettingsSchema,
  recordPaymentSchema, 
  PaymentStatus,
  PaymentStatusType,
  PaymentMode,
  TransactionType,
  entries,
  expenseEntries,
  advancePayments,
  previousOutstandingRecords,
  corpusSettings
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";



export async function registerRoutes(app: Express): Promise<Server> {
  const { TransactionType } = await import("@shared/schema");
  
  // Serve uploaded files statically
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  
  // Set up session store
  const MemoryStoreSession = MemoryStore(session);
  
  app.use(session({
    secret: process.env.SESSION_SECRET || "ledger-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 },
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // Prune expired entries every 24h
    })
  }));

  // Set up authentication
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return done(null, false, { message: "Incorrect username" });
      }
      if (user.password !== password) {
        return done(null, false, { message: "Incorrect password" });
      }
      if (user.status !== "active") {
        return done(null, false, { message: "User account is inactive" });
      }
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Auth middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  const isAdmin = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated() && req.user && (req.user as any).role === "admin") {
      return next();
    }
    res.status(403).json({ message: "Forbidden: Admin access required" });
  };

  const isAdminOrOperator = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated() && req.user && 
        ((req.user as any).role === "admin" || (req.user as any).role === "operator")) {
      return next();
    }
    res.status(403).json({ message: "Forbidden: Admin or Operator access required" });
  };
  
  const isOperator = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated() && req.user && (req.user as any).role === "operator") {
      return next();
    }
    res.status(403).json({ message: "Forbidden: Operator access required" });
  };

  // Auth routes
  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: Error, user: any, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: info.message || "Authentication failed" });
      
      req.logIn(user, (err) => {
        if (err) return next(err);
        return res.json({ 
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
          mobile: user.mobile,
          address: user.address
        });
      });
    })(req, res, next);
  });

  app.get("/api/auth/user", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = req.user as any;
    res.json({
      id: user.id,
      username: user.username,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
      mobile: user.mobile,
      address: user.address
    });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.json({ success: true });
    });
  });

  // Set up multer for file uploads
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const storage_multer = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
      // Create unique filename with timestamp
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  });

  const upload = multer({ 
    storage: storage_multer,
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = [
        'image/jpeg',
        'image/jpg', 
        'image/png',
        'application/pdf',
        'text/csv',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      ];
      
      if (file.fieldname === 'receiptFile' || file.fieldname === 'paymentScreenshot' || file.fieldname === 'attachmentFile') {
        const imageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
        if (imageTypes.includes(file.mimetype)) {
          cb(null, true);
        } else {
          cb(new Error('Only JPG, JPEG, PNG and PDF files are allowed'));
        }
      } else if (file.fieldname === 'file') {
        // For bulk upload files
        const csvTypes = ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
        if (csvTypes.includes(file.mimetype) || file.originalname.endsWith('.csv')) {
          cb(null, true);
        } else {
          cb(new Error('Only CSV and Excel files are allowed for bulk upload'));
        }
      } else {
        cb(new Error('Unexpected field'));
      }
    }
  });
  
  // Update current user's profile
  app.patch("/api/auth/profile", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const userId = currentUser.id;
      
      // Only allow certain fields to be updated
      const allowedUpdates = ["name", "email", "mobile", "address"];
      const updates: any = {};
      
      Object.keys(req.body).forEach(key => {
        if (allowedUpdates.includes(key)) {
          updates[key] = req.body[key];
        }
      });
      
      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Invalidate caches to ensure updated data is reflected everywhere
      (req as any).sessionStore.all((err: any, sessions: any) => {
        if (sessions) {
          Object.values(sessions).forEach((session: any) => {
            const wsClient = (req as any).app.get('wsClients')?.get(session.id);
            if (wsClient) {
              wsClient.send(JSON.stringify({
                type: 'CACHE_INVALIDATION',
                keys: [
                  '/api/users',
                  '/api/entries',
                  '/api/dashboard',
                  '/api/auth/user'
                ]
              }));
            }
          });
        }
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // User management routes
  app.get("/api/users", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.user as any;
      
      // Only allow admin and operator to access users
      if (currentUser.role !== 'admin' && currentUser.role !== 'operator') {
        return res.status(403).json({ message: "Forbidden: Admin or Operator access required" });
      }
      
      const users = await storage.getUsers();
      
      // If operator, filter out admin users
      if (currentUser.role === 'operator') {
        const filteredUsers = users.filter(user => user.role !== 'admin');
        return res.json(filteredUsers);
      }
      
      // Admins can see all users
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Get specific user details with related data
  app.get("/api/users/:id", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const userId = parseInt(req.params.id);

      // Allow users to view their own profile, or admin/operator to view others
      const canViewProfile = 
        currentUser.id === userId || // User viewing their own profile
        currentUser.role === 'admin' || 
        currentUser.role === 'operator';

      if (!canViewProfile) {
        return res.status(403).json({ message: "Forbidden: Can only view your own profile" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // If operator, don't allow viewing admin users (except their own profile)
      if (currentUser.role === 'operator' && user.role === 'admin' && currentUser.id !== userId) {
        return res.status(403).json({ message: "Forbidden: Cannot view admin user" });
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user details" });
    }
  });

  // Note: /api/entries route is defined elsewhere in the file, this just adds userId filtering

  // Note: advance-payments and dravya-entries routes may be defined elsewhere

  // Get user's advance balance
  app.get("/api/users/:id/advance-balance", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const balance = await storage.calculateRemainingAdvancePayment(userId);
      res.json(balance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch advance balance" });
    }
  });

  // Bulk user upload endpoint
  app.post("/api/users/bulk-upload", isAdminOrOperator, upload.single('file'), async (req, res) => {
    try {
      const currentUser = req.user as any;
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const filePath = req.file.path;
      let errors = 0;
      let created = 0;

      // Read CSV file
      const readCSV = () => {
        return new Promise<any[]>((resolve, reject) => {
          const results: any[] = [];
          fs.createReadStream(filePath)
            .pipe(csv())
            .on('data', (data) => results.push(data))
            .on('end', () => resolve(results))
            .on('error', reject);
        });
      };

      try {
        const csvData = await readCSV();
        
        for (const row of csvData) {
          try {
            // Validate required fields
            if (!row.username || !row.password || !row.name || !row.email) {
              errors++;
              continue;
            }

            // Role validation based on current user
            const validRoles = currentUser.role === 'admin' 
              ? ['admin', 'operator', 'viewer'] 
              : ['operator', 'viewer'];
            
            if (!validRoles.includes(row.role)) {
              errors++;
              continue;
            }

            // Create user data
            const userData = {
              username: row.username.trim(),
              password: row.password.trim(),
              name: row.name.trim(),
              email: row.email.trim(),
              mobile: row.mobile ? row.mobile.trim() : "",
              address: row.address ? row.address.trim() : "",
              role: row.role.trim(),
              status: row.status ? row.status.trim() : "active"
            };

            // Validate with schema
            const validatedData = insertUserSchema.parse(userData);
            
            // Check if username already exists
            const existingUser = await storage.getUserByUsername(validatedData.username);
            if (existingUser) {
              errors++;
              continue;
            }

            // Create user
            await storage.createUser(validatedData);
            created++;
            
          } catch (error) {
            console.error("Error creating user from CSV:", error);
            errors++;
          }
        }

        // Clean up uploaded file
        fs.unlinkSync(filePath);

        res.json({
          message: "Bulk upload completed",
          created,
          errors,
          total: csvData.length
        });

      } catch (error) {
        // Clean up uploaded file in case of error
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
        throw error;
      }

    } catch (error) {
      console.error("Bulk upload error:", error);
      res.status(500).json({ message: "Failed to process bulk upload" });
    }
  });

  // Check for duplicate mobile number
  app.post("/api/users/check-mobile", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.user as any;
      
      // Only allow admin and operator to check mobile numbers
      if (currentUser.role !== 'admin' && currentUser.role !== 'operator') {
        return res.status(403).json({ message: "Forbidden: Admin or Operator access required" });
      }

      const { mobile } = req.body;
      
      if (!mobile) {
        return res.status(400).json({ message: "Mobile number is required" });
      }

      // Check if mobile number already exists
      const existingUser = await storage.getUserByMobile(mobile);
      
      if (existingUser) {
        return res.status(200).json({ 
          exists: true, 
          user: {
            id: existingUser.id,
            name: existingUser.name,
            username: existingUser.username,
            mobile: existingUser.mobile
          }
        });
      } else {
        return res.status(200).json({ exists: false });
      }
    } catch (error) {
      console.error("Error checking mobile number:", error);
      res.status(500).json({ message: "Failed to check mobile number" });
    }
  });

  app.post("/api/users", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.user as any;
      
      // Only allow admin and operator to create users
      if (currentUser.role !== 'admin' && currentUser.role !== 'operator') {
        return res.status(403).json({ message: "Forbidden: Admin or Operator access required" });
      }
      
      const userData = insertUserSchema.parse(req.body);
      
      // Operators cannot create admin users
      if (currentUser.role === 'operator' && userData.role === 'admin') {
        return res.status(403).json({ message: "Forbidden: Operators cannot create admin users" });
      }

      // Check for duplicate mobile number before creating user
      if (userData.mobile) {
        const existingUser = await storage.getUserByMobile(userData.mobile);
        if (existingUser) {
          return res.status(400).json({ 
            message: `Mobile number already exists for user: ${existingUser.name} (${existingUser.username})` 
          });
        }
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", isAuthenticated, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const userId = parseInt(req.params.id);
      
      // Only allow admin and operator to update users
      if (currentUser.role !== 'admin' && currentUser.role !== 'operator') {
        return res.status(403).json({ message: "Forbidden: Admin or Operator access required" });
      }
      
      // Get the user being updated to check their role
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Operators cannot edit admin users
      if (currentUser.role === 'operator' && existingUser.role === 'admin') {
        return res.status(403).json({ message: "Forbidden: Operators cannot edit admin users" });
      }
      
      // Operators cannot change user role to admin
      if (currentUser.role === 'operator' && req.body.role === 'admin') {
        return res.status(403).json({ message: "Forbidden: Operators cannot assign admin role" });
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Since we're updating a user, we need to clear all entry caches where this user is referenced
      // This ensures entries will show the updated user name
      (req as any).sessionStore.all((err: any, sessions: any) => {
        if (sessions) {
          Object.values(sessions).forEach((session: any) => {
            const wsClient = (req as any).app.get('wsClients')?.get(session.id);
            if (wsClient) {
              wsClient.send(JSON.stringify({
                type: 'CACHE_INVALIDATION',
                keys: [
                  '/api/users',
                  '/api/entries',
                  `/api/entries/${userId}`,
                  '/api/dashboard'
                ]
              }));
            }
          });
        }
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Entry management routes - only for boli entries
  app.get("/api/entries", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { userId } = req.query;
      let entries;
      
      if (userId) {
        // Specific user requested - only for admin/operator or current user
        const targetUserId = parseInt(userId.toString());
        if (user.role === "admin" || user.role === "operator" || user.id === targetUserId) {
          entries = await storage.getUserEntries(targetUserId);
        } else {
          return res.status(403).json({ message: "Access denied" });
        }
      } else {
        // No specific user - use role-based logic
        if (user.role === "admin" || user.role === "operator") {
          entries = await storage.getEntries();
        } else {
          entries = await storage.getUserEntries(user.id);
        }
      }
      
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch entries" });
    }
  });

  // Separate dravya entries routes - completely isolated
  app.get("/api/dravya-entries", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { userId } = req.query;
      const { pool } = await import("./db");
      
      let sql: string, values: any[];
      
      if (userId) {
        // Specific user requested - only for admin/operator or current user
        const targetUserId = parseInt(userId.toString());
        if (user.role === "admin" || user.role === "operator" || user.id === targetUserId) {
          sql = "SELECT * FROM dravya_entries WHERE user_id = $1 ORDER BY id DESC";
          values = [targetUserId];
        } else {
          return res.status(403).json({ message: "Access denied" });
        }
      } else {
        // No specific user - use role-based logic
        if (user.role === "admin" || user.role === "operator") {
          sql = "SELECT * FROM dravya_entries ORDER BY id DESC";
          values = [];
        } else {
          sql = "SELECT * FROM dravya_entries WHERE user_id = $1 ORDER BY id DESC";
          values = [user.id];
        }
      }
      
      const result = await pool.query(sql, values);
      const dravyaEntries = result.rows.map(row => ({
        ...row,
        userId: row.user_id,
        userName: row.user_name,
        userMobile: row.user_mobile,
        userAddress: row.user_address,
        entryDate: row.entry_date,
        createdBy: row.created_by,
        updatedAt: row.updated_at
      }));
      
      res.json(dravyaEntries);
    } catch (error) {
      console.error("Error fetching dravya entries:", error);
      res.status(500).json({ message: "Failed to fetch dravya entries" });
    }
  });

  app.get("/api/entries/:id", isAuthenticated, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const entry = await storage.getEntry(entryId);
      
      if (!entry) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      const user = req.user as any;
      if (user.role !== "admin" && user.role !== "operator" && entry.userId !== user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch entry" });
    }
  });

  // Only operators can create entries
  // Separate endpoint for creating dravya entries
  app.post("/api/dravya-entries", isAdminOrOperator, async (req, res) => {
    try {
      console.log("Dravya entry creation data:", req.body);
      
      // Parse and validate the data using Zod
      const dravyaData = insertDravyaEntrySchema.parse(req.body);
      console.log("Parsed dravya entry data:", dravyaData);
      
      const currentUser = req.user as any;
      console.log("Current user:", currentUser.id, currentUser.username);
      
      const { pool } = await import("./db");
      
      // Get the user data
      const user = await storage.getUser(dravyaData.userId);
      
      // Create the dravya entry
      const sql = `
        INSERT INTO dravya_entries (
          user_id, user_name, user_mobile, user_address,
          description, occasion, entry_date, created_by, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9
        ) RETURNING *
      `;
      
      const values = [
        dravyaData.userId,
        user?.name || dravyaData.userName || 'Unknown User',
        user?.mobile || '',
        user?.address || '',
        dravyaData.description || '',
        dravyaData.occasion || '',
        dravyaData.entryDate || new Date().toISOString().split('T')[0],
        currentUser ? currentUser.username : 'system',
        new Date().toISOString()
      ];
      
      console.log("Executing dravya SQL with values:", values);
      
      const result = await pool.query(sql, values);
      console.log("Dravya entry creation result:", result.rows[0]);
      
      // Map the raw DB object to our format
      const rawEntry = result.rows[0];
      const dravyaEntry = {
        ...rawEntry,
        userId: rawEntry.user_id,
        userName: rawEntry.user_name,
        userMobile: rawEntry.user_mobile,
        userAddress: rawEntry.user_address,
        entryDate: rawEntry.entry_date,
        createdBy: rawEntry.created_by,
        updatedAt: rawEntry.updated_at
      };
      
      console.log("Dravya entry created successfully:", dravyaEntry);
      
      // Send mobile notification for dravya entry
      console.log(`[MOBILE NOTIFICATION] New dravya entry created for ${dravyaEntry.userName} (${dravyaEntry.userMobile})`);
      console.log(`Dravya Entry: ${dravyaEntry.description}`);
      
      res.status(201).json(dravyaEntry);
    } catch (error) {
      console.error("Error creating dravya entry:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create dravya entry" });
    }
  });

  // GET expense entries (only for operators) with optional date filtering
  app.get("/api/expense-entries", isAdminOrOperator, async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const { pool } = await import("./db");
      
      let sql = 'SELECT * FROM expense_entries WHERE 1=1';
      const params: any[] = [];
      
      // Add date range filtering if provided
      if (startDate) {
        sql += ` AND expense_date >= $${params.length + 1}`;
        params.push(startDate);
      }
      
      if (endDate) {
        sql += ` AND expense_date <= $${params.length + 1}`;
        params.push(endDate);
      }
      
      sql += ' ORDER BY expense_date DESC, id DESC';
      
      const result = await pool.query(sql, params);
      res.json(result.rows);
    } catch (error) {
      console.error("Error fetching expense entries:", error);
      res.status(500).json({ message: "Failed to fetch expense entries" });
    }
  });

  // POST new expense entry (only for operators) with file uploads
  app.post("/api/expense-entries", isAdminOrOperator, upload.fields([
    { name: 'receiptFile', maxCount: 1 },
    { name: 'paymentScreenshot', maxCount: 1 }
  ]), async (req, res) => {
    try {
      console.log("Expense entry creation data:", req.body);
      console.log("Uploaded files:", req.files);
      
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      // Parse form data from multipart request
      const expenseData = {
        firmName: req.body.firmName || null,
        billNo: req.body.billNo || null,
        billDate: req.body.billDate || null,
        description: req.body.description,
        amount: parseInt(req.body.amount),
        quantity: req.body.quantity ? parseInt(req.body.quantity) : null,
        reason: req.body.reason || null,
        expenseDate: req.body.expenseDate,
        paymentMode: req.body.paymentMode,
        approvedBy: req.body.approvedBy,
        paidBy: req.body.paidBy,
        createdBy: req.body.createdBy
      };
      
      // Validate the parsed data
      const validatedData = insertExpenseEntrySchema.parse(expenseData);
      console.log("Parsed expense entry data:", validatedData);
      
      const currentUser = req.user as any;
      console.log("Current user:", currentUser.id, currentUser.username);
      
      // Handle file uploads
      let receiptUrl = null;
      let paymentScreenshotUrl = null;
      
      if (files.receiptFile && files.receiptFile[0]) {
        receiptUrl = `/uploads/${files.receiptFile[0].filename}`;
      }
      
      if (files.paymentScreenshot && files.paymentScreenshot[0]) {
        paymentScreenshotUrl = `/uploads/${files.paymentScreenshot[0].filename}`;
      }
      
      // Create expense entry with raw SQL
      const { pool } = await import("./db");
      
      const sql = `
        INSERT INTO expense_entries (
          firm_name, bill_no, bill_date, description, amount, quantity, reason,
          expense_date, payment_mode, attachment_url, approved_by, paid_by,
          created_by, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11, $12,
          $13, $14
        ) RETURNING *
      `;
      
      // Combine receipt and payment screenshot URLs
      const attachmentUrls = [receiptUrl, paymentScreenshotUrl].filter(Boolean).join(';');
      
      const values = [
        validatedData.firmName,
        validatedData.billNo,
        validatedData.billDate,
        validatedData.description,
        validatedData.amount,
        validatedData.quantity,
        validatedData.reason,
        validatedData.expenseDate,
        validatedData.paymentMode,
        attachmentUrls || null,
        validatedData.approvedBy,
        validatedData.paidBy,
        currentUser ? currentUser.username : 'system',
        new Date().toISOString()
      ];
      
      console.log("Executing expense SQL with values:", values);
      
      const result = await pool.query(sql, values);
      console.log("Expense entry creation result:", result.rows[0]);
      
      const expenseEntry = result.rows[0];
      
      console.log("Expense entry created successfully:", expenseEntry);
      
      // Send mobile notification for expense entry
      console.log(`[MOBILE NOTIFICATION] New expense entry created: ${expenseEntry.description}`);
      console.log(`Amount: ₹${(expenseEntry.amount / 100).toFixed(2)} | Approved by: ${expenseEntry.approved_by}`);
      
      res.status(201).json(expenseEntry);
    } catch (error) {
      console.error("Error creating expense entry:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create expense entry" });
    }
  });

  // Function to calculate remaining advance payments for a user
  async function calculateRemainingAdvancePayment(userId: number): Promise<number> {
    const { pool } = await import("./db");
    
    // Get total advance payments for the user
    const advanceResult = await pool.query(
      'SELECT COALESCE(SUM(amount), 0) as total_advance FROM advance_payments WHERE user_id = $1',
      [userId]
    );
    
    // Get total used advance payments (payments made using advance)
    const usedResult = await pool.query(
      'SELECT COALESCE(SUM(amount), 0) as total_used FROM advance_payment_usage WHERE user_id = $1',
      [userId]
    );
    
    const totalAdvance = parseInt(advanceResult.rows[0]?.total_advance || '0');
    const totalUsed = parseInt(usedResult.rows[0]?.total_used || '0');
    
    console.log(`[DEBUG] User ${userId} - Total Advance: ${totalAdvance}, Total Used: ${totalUsed}`);
    
    const remainingBalance = totalAdvance - totalUsed;
    
    console.log(`[DEBUG] User ${userId} - Calculated Balance: ${remainingBalance}`);
    
    // Return 0 if balance would be negative (user can't have negative advance balance)
    const finalBalance = Math.max(0, remainingBalance);
    console.log(`[DEBUG] User ${userId} - Final Balance: ${finalBalance}`);
    
    return finalBalance;
  }

  // Function to auto-process boli payment using advance payment
  async function autoProcessBoliPayment(entryId: number, userId: number, boliAmount: number, boliDate: string, createdBy: string): Promise<void> {
    const { pool } = await import("./db");
    
    const remainingAdvance = await calculateRemainingAdvancePayment(userId);
    
    if (remainingAdvance > 0) {
      const paymentAmount = Math.min(remainingAdvance, boliAmount);
      
      // Record the advance payment usage
      await pool.query(
        'INSERT INTO advance_payment_usage (user_id, entry_id, amount, date, created_by, created_at) VALUES ($1, $2, $3, $4, $5, $6)',
        [userId, entryId, paymentAmount, boliDate, createdBy, new Date().toISOString()]
      );
      
      // Create payment record
      const paymentRecord = {
        date: boliDate,
        amount: paymentAmount,
        mode: 'advance_payment' as any,
        receiptNo: `ADV${new Date().getFullYear()}${String(Date.now()).slice(-6)}`,
        updatedBy: createdBy
      };
      
      // Update the entry with the payment
      const entry = await storage.getEntry(entryId);
      if (entry) {
        const updatedPayments = [...entry.payments, paymentRecord];
        const newReceivedAmount = entry.receivedAmount + paymentAmount;
        const newPendingAmount = entry.totalAmount - newReceivedAmount;
        
        let newStatus: PaymentStatusType;
        if (newPendingAmount <= 0) {
          newStatus = PaymentStatus.FULL;
        } else if (newReceivedAmount > 0) {
          newStatus = PaymentStatus.PARTIAL;
        } else {
          newStatus = PaymentStatus.PENDING;
        }
        
        await pool.query(
          `UPDATE entries SET 
           payments = $1, received_amount = $2, pending_amount = $3, status = $4, updated_at = $5
           WHERE id = $6`,
          [JSON.stringify(updatedPayments), newReceivedAmount, newPendingAmount, newStatus, new Date().toISOString(), entryId]
        );
      }
    }
  }

  // API endpoint to process advance payment for a boli entry
  app.post("/api/entries/:id/advance-payment", isAuthenticated, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const { amount, date } = req.body;
      const user = req.user as any;
      const userId = user?.id;

      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }

      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid payment amount" });
      }

      const { pool } = await import("./db");

      // Get the boli entry to find the user
      const entryResult = await pool.query('SELECT * FROM entries WHERE id = $1', [entryId]);
      if (entryResult.rows.length === 0) {
        return res.status(404).json({ message: "Boli entry not found" });
      }
      
      const entry = entryResult.rows[0];
      const entryUserId = entry.user_id;

      // Get user's advance payment balance
      const remainingBalance = await calculateRemainingAdvancePayment(entryUserId);
      
      if (remainingBalance < amount) {
        return res.status(400).json({ message: "Insufficient advance payment balance" });
      }

      // Record the advance payment usage
      await pool.query(
        'INSERT INTO advance_payment_usage (user_id, entry_id, amount, date, created_by, created_at) VALUES ($1, $2, $3, $4, $5, $6)',
        [entryUserId, entryId, amount, date, user.username, new Date().toISOString()]
      );

      // Create payment record with advance payment mode
      const receiptNo = `ADV-${new Date().getFullYear()}${String(Date.now()).slice(-6)}`;
      
      const paymentData = {
        date,
        amount,
        mode: 'advance_payment',
        receiptNo,
        updatedBy: user.username
      };

      // Get current entry payments
      const currentEntry = await pool.query('SELECT payments FROM entries WHERE id = $1', [entryId]);
      const currentPayments = currentEntry.rows[0]?.payments || [];
      
      // Add new payment
      const updatedPayments = [...currentPayments, paymentData];
      
      // Calculate new totals
      const totalReceived = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
      const pendingAmount = entry.total_amount - totalReceived;
      const status = pendingAmount <= 0 ? 'full' : totalReceived > 0 ? 'partial' : 'pending';

      // Update the entry
      await pool.query(
        'UPDATE entries SET payments = $1, received_amount = $2, pending_amount = $3, status = $4, updated_at = $5 WHERE id = $6',
        [JSON.stringify(updatedPayments), totalReceived, pendingAmount, status, new Date().toISOString(), entryId]
      );

      // Log the transaction
      await pool.query(
        'INSERT INTO transaction_logs (entry_id, user_id, username, transaction_type, amount, description, date, details, timestamp) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [
          entryId,
          entryUserId,
          user.username,
          'advance_payment_applied',
          amount,
          `Applied ₹${amount} from advance payment balance`,
          date,
          JSON.stringify({ 
            receiptNo,
            previousStatus: entry.status,
            newStatus: status,
            remainingBalance: remainingBalance - amount
          }),
          new Date().toISOString()
        ]
      );

      res.json({ 
        success: true, 
        payment: paymentData, 
        entry: {
          ...entry,
          payments: updatedPayments,
          received_amount: totalReceived,
          pending_amount: pendingAmount,
          status
        }
      });

    } catch (error) {
      console.error("Error processing advance payment:", error);
      res.status(500).json({ message: "Failed to process advance payment" });
    }
  });

  // API endpoint to get remaining advance payment balance for a user
  app.get("/api/users/:id/advance-balance", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      console.log(`Calculating advance balance for user ${userId}`);
      const remainingBalance = await calculateRemainingAdvancePayment(userId);
      console.log(`Advance balance result for user ${userId}: ${remainingBalance}`);
      
      // Set cache headers to prevent caching
      res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      res.json(remainingBalance); // Return just the number, not an object
    } catch (error) {
      console.error("Error fetching user advance balance:", error);
      res.status(500).json({ message: "Failed to fetch advance balance" });
    }
  });

  // Advance payments routes (completely separate module)
  app.get("/api/advance-payments", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { startDate, endDate, userId } = req.query;
      const { pool } = await import("./db");
      
      let sql = `SELECT ap.*, u.address as user_address 
                 FROM advance_payments ap 
                 LEFT JOIN users u ON ap.user_id = u.id 
                 WHERE 1=1`;
      const params: any[] = [];
      
      // Add user filtering if specified
      if (userId) {
        const targetUserId = parseInt(userId.toString());
        if (user.role === "admin" || user.role === "operator" || user.id === targetUserId) {
          sql += ` AND ap.user_id = $${params.length + 1}`;
          params.push(targetUserId);
        } else {
          return res.status(403).json({ message: "Access denied" });
        }
      } else if (user.role !== "admin" && user.role !== "operator") {
        // Non-admin/operator users can only see their own advance payments
        sql += ` AND ap.user_id = $${params.length + 1}`;
        params.push(user.id);
      }
      
      // Add date range filtering if provided
      if (startDate) {
        sql += ` AND date >= $${params.length + 1}`;
        params.push(startDate);
      }
      
      if (endDate) {
        sql += ` AND date <= $${params.length + 1}`;
        params.push(endDate);
      }
      
      sql += ' ORDER BY date DESC, id DESC';
      
      const result = await pool.query(sql, params);
      const advancePayments = result.rows.map(row => ({
        ...row,
        userId: row.user_id,
        userName: row.user_name,
        userMobile: row.user_mobile,
        userAddress: row.user_address,
        paymentMode: row.payment_mode,
        attachmentUrl: row.attachment_url,
        receiptNo: row.receipt_no,
        createdBy: row.created_by,
        createdAt: row.created_at
      }));
      
      res.json(advancePayments);
    } catch (error) {
      console.error("Error fetching advance payments:", error);
      res.status(500).json({ message: "Failed to fetch advance payments" });
    }
  });

  // Function to generate unified receipt number for all payment types
  async function generateUnifiedReceiptNumber(paymentDate: string): Promise<string> {
    const { pool } = await import("./db");
    const year = paymentDate.split('-')[0]; // Extract year from YYYY-MM-DD
    
    let highestSequence = 0;
    
    // Check transaction logs for payment receipts (SPDJMSJ-YYYY-XXXXX format)
    const logs = await storage.getTransactionLogs();
    for (const log of logs) {
      if (!log.details) continue;
      
      const details = typeof log.details === 'string' ? JSON.parse(log.details) : log.details;
      if (!details.receiptNo) continue;
      
      if (typeof details.receiptNo === 'string' && details.receiptNo.startsWith(`SPDJMSJ-${year}-`)) {
        const match = details.receiptNo.match(/SPDJMSJ-\d{4}-(\d{5})/);
        if (match && match[1]) {
          const foundNumber = parseInt(match[1], 10);
          if (!isNaN(foundNumber) && foundNumber > highestSequence) {
            highestSequence = foundNumber;
          }
        }
      }
    }
    
    // Check advance payments table for ADV receipts (need to be in same sequence as SPDJMSJ)
    const advanceResult = await pool.query(
      `SELECT receipt_no FROM advance_payments 
       WHERE receipt_no LIKE $1 AND receipt_no IS NOT NULL`,
      [`ADV-${year}-%`]
    );
    
    for (const row of advanceResult.rows) {
      const match = row.receipt_no.match(/ADV-\d{4}-(\d{5})/);
      if (match && match[1]) {
        const foundNumber = parseInt(match[1], 10);
        if (!isNaN(foundNumber) && foundNumber > highestSequence) {
          highestSequence = foundNumber;
        }
      }
    }
    
    // Next sequence number
    const sequenceNumber = highestSequence + 1;
    const formattedNumber = sequenceNumber.toString().padStart(5, '0');
    return `SPDJMSJ-${year}-${formattedNumber}`;
  }

  // Function to generate advance payment receipt number (uses same sequence as regular payments)
  async function generateAdvancePaymentReceiptNumber(paymentDate: string): Promise<string> {
    const receiptNo = await generateUnifiedReceiptNumber(paymentDate);
    // Convert SPDJMSJ- to ADV- for advance payments while maintaining same sequence
    return receiptNo.replace('SPDJMSJ-', 'ADV-');
  }

  // POST new advance payment with file upload
  app.post("/api/advance-payments", isAdminOrOperator, upload.single('paymentScreenshot'), async (req, res) => {
    try {
      console.log("Advance payment creation data:", req.body);
      console.log("Uploaded file:", req.file);
      
      // Parse form data from multipart request
      const advancePaymentData = {
        userId: parseInt(req.body.userId),
        userName: req.body.userName,
        userMobile: req.body.userMobile || '',
        date: req.body.date,
        amount: parseInt(req.body.amount), // Amount already in correct format
        paymentMode: req.body.paymentMode,
        createdBy: req.body.createdBy
      };
      
      // Validate the parsed data
      const validatedData = insertAdvancePaymentSchema.parse(advancePaymentData);
      console.log("Parsed advance payment data:", validatedData);
      
      const currentUser = req.user as any;
      console.log("Current user:", currentUser.id, currentUser.username);
      
      // Handle file upload for payment screenshot
      let attachmentUrl = null;
      if (req.file) {
        attachmentUrl = `/uploads/${req.file.filename}`;
      }
      
      // Generate receipt number for advance payment
      const receiptNo = await generateAdvancePaymentReceiptNumber(validatedData.date);
      
      // Create advance payment with raw SQL
      const { pool } = await import("./db");
      
      const sql = `
        INSERT INTO advance_payments (
          user_id, user_name, user_mobile, date,
          amount, payment_mode, attachment_url, receipt_no, created_by, created_at
        ) VALUES (
          $1, $2, $3, $4,
          $5, $6, $7, $8, $9, $10
        ) RETURNING *
      `;
      
      const values = [
        validatedData.userId,
        validatedData.userName,
        validatedData.userMobile || '',
        validatedData.date,
        validatedData.amount,
        validatedData.paymentMode,
        attachmentUrl,
        receiptNo,
        currentUser ? currentUser.username : 'system',
        new Date().toISOString()
      ];
      
      console.log("Executing advance payment SQL with values:", values);
      
      const result = await pool.query(sql, values);
      console.log("Advance payment creation result:", result.rows[0]);
      
      const advancePayment = result.rows[0];
      
      console.log("Advance payment created successfully:", advancePayment);
      
      res.status(201).json({
        ...advancePayment,
        userId: advancePayment.user_id,
        userName: advancePayment.user_name,
        userMobile: advancePayment.user_mobile,
        paymentMode: advancePayment.payment_mode,
        attachmentUrl: advancePayment.attachment_url,
        receiptNo: advancePayment.receipt_no,
        createdBy: advancePayment.created_by,
        createdAt: advancePayment.created_at
      });
    } catch (error) {
      console.error("Error creating advance payment:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create advance payment" });
    }
  });

  app.post("/api/entries", isAdminOrOperator, async (req, res) => {
    try {
      console.log("Entry creation data:", req.body);
      const entryData = insertEntrySchema.parse(req.body);
      console.log("Parsed entry data:", entryData);
      
      const currentUser = req.user as any;
      console.log("Current user:", currentUser.id, currentUser.username);
      
      // Validate that the boli date is not in the future
      const boliDate = new Date(entryData.auctionDate);
      const today = new Date();
      today.setHours(23, 59, 59, 999); // Set to end of today
      
      if (boliDate > today) {
        return res.status(400).json({ 
          message: "Boli date cannot be in the future. Please select today's date or earlier." 
        });
      }
      
      // Create entry and pass the current user's ID (who is creating the entry)
      // Use direct SQL to create the entry with proper column names
      const { pool } = await import("./db");
      
      // Map the fields correctly for auction entries
      const quantity = entryData.quantity || 1;
      const totalAmount = entryData.amount * quantity;
      
      // Get the user data
      const user = await storage.getUser(entryData.userId);
      
      // Create the entry with raw SQL to ensure column names match
      const sql = `
        INSERT INTO entries (
          user_id, user_name, user_mobile, user_address,
          description, amount, quantity, total_amount,
          occasion, auction_date, pending_amount, received_amount,
          status, payments, created_by
        ) VALUES (
          $1, $2, $3, $4,
          $5, $6, $7, $8,
          $9, $10, $11, $12,
          $13, $14, $15
        ) RETURNING *
      `;
      
      const values = [
        entryData.userId,
        user?.name || entryData.userName || 'Unknown User',
        user?.mobile || '',
        user?.address || '',
        entryData.description || '',
        entryData.amount || 0,
        quantity,
        totalAmount,
        entryData.occasion || '',
        entryData.auctionDate || new Date().toISOString().split('T')[0],
        totalAmount,
        0,
        'pending',
        '[]',
        currentUser ? currentUser.username : 'system'
      ];
      
      console.log("Executing SQL with values:", values);
      
      const result = await pool.query(sql, values);
      console.log("Entry creation result:", result.rows[0]);
      
      // Create a transaction log for this entry creation (CREDIT)
      const logSql = `
        INSERT INTO transaction_logs (
          entry_id, user_id, username, description, 
          amount, transaction_type, details, date, timestamp
        ) VALUES (
          $1, $2, $3, $4, 
          $5, $6, $7, $8, $9
        )
      `;
      
      const logValues = [
        result.rows[0].id,
        currentUser.id,
        currentUser.username,
        `Entry created for ${user?.name || entryData.userName || 'Unknown User'} by ${currentUser.username}`,
        totalAmount,
        'credit', // Explicitly setting transaction_type to 'credit'
        JSON.stringify({
          description: entryData.description,
          occasion: entryData.occasion,
          auctionDate: entryData.auctionDate
        }),
        new Date().toISOString().split('T')[0],
        new Date().toISOString()
      ];
      
      await pool.query(logSql, logValues);
      console.log("Transaction log created for entry creation");
      
      // Map the raw DB object to our format
      const rawEntry = result.rows[0];
      const entry = {
        ...rawEntry,
        userId: rawEntry.user_id,
        userName: rawEntry.user_name,
        userMobile: rawEntry.user_mobile,
        userAddress: rawEntry.user_address,
        totalAmount: rawEntry.total_amount,
        pendingAmount: rawEntry.pending_amount,
        receivedAmount: rawEntry.received_amount,
        auctionDate: rawEntry.auction_date,
        updatedAt: rawEntry.updated_at,
        createdBy: rawEntry.created_by,
        entryType: rawEntry.entry_type,
        unitOfMeasurement: rawEntry.unit_of_measurement
      };
      console.log("Entry created successfully:", entry);
      
      // Auto-process boli payment using advance payment if available
      try {
        await autoProcessBoliPayment(
          entry.id, 
          entry.userId, 
          entry.totalAmount, 
          entry.auctionDate, 
          currentUser.username
        );
        console.log("Auto-payment processing completed for entry:", entry.id);
      } catch (error) {
        console.error("Error in auto-payment processing:", error);
        // Don't fail the entry creation if auto-payment fails
      }
      
      // Get the user for whom the entry was created
      const entryUser = await storage.getUser(entry.userId);
      
      // If entryUser exists, send notification
      if (entryUser) {
        // Import is done inside the handler to avoid circular dependencies
        const { NotificationService } = await import("./notification");
        NotificationService.notifyEntryCreated(entryUser, entry);
      }
      
      res.status(201).json(entry);
    } catch (error) {
      console.error("Error creating entry:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create entry" });
    }
  });

  // Entry update endpoint (for operators and admins with role-based field restrictions)
  app.put("/api/entries/:id", isAdminOrOperator, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const currentUser = req.user as any;
      
      // Get the current entry to compare changes
      const existingEntry = await storage.getEntry(entryId);
      if (!existingEntry) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      // Parse and validate the request body
      const updateData = insertEntrySchema.omit({ 
        createdBy: true 
      }).parse({
        ...req.body,
        totalAmount: req.body.totalAmount, // Keep as number for validation
        quantity: req.body.quantity
      });
      
      // Role-based field restrictions
      if (currentUser.role === 'operator') {
        // Operators cannot edit the totalAmount field
        if (updateData.totalAmount !== existingEntry.totalAmount) {
          return res.status(403).json({ 
            message: "Operators cannot modify the total amount. Only administrators can edit this field." 
          });
        }
        
        // Operators cannot change the user selection
        if (updateData.userId !== existingEntry.userId) {
          return res.status(403).json({ 
            message: "Operators cannot change the user selection. Only administrators can edit this field." 
          });
        }
      }
      
      // Validate that the boli date is not in the future
      const boliDate = new Date(updateData.auctionDate);
      const today = new Date();
      today.setHours(23, 59, 59, 999); // Set to end of today
      
      if (boliDate > today) {
        return res.status(400).json({ 
          message: "Boli date cannot be in the future. Please select today's date or earlier." 
        });
      }
      
      // Convert amounts to paisa for storage
      const totalAmountPaisa = Math.round(updateData.totalAmount * 100);
      const updatedEntryData = {
        ...updateData,
        totalAmount: totalAmountPaisa,
        updatedAt: new Date().toISOString(),
      };
      
      // Update the entry
      const updatedEntry = await storage.updateEntry(entryId, updatedEntryData, currentUser.id);
      
      if (!updatedEntry) {
        return res.status(500).json({ message: "Failed to update entry" });
      }
      
      // Log the transaction
      const logSql = `
        INSERT INTO transaction_logs (
          entry_id, user_id, username, description, 
          amount, transaction_type, details, date, timestamp
        ) VALUES (
          $1, $2, $3, $4, 
          $5, $6, $7, $8, $9
        )
      `;
      
      const changes = {
        before: {
          description: existingEntry.description,
          totalAmount: existingEntry.totalAmount,
          quantity: existingEntry.quantity,
          occasion: existingEntry.occasion,
          auctionDate: existingEntry.auctionDate
        },
        after: {
          description: updateData.description,
          totalAmount: updateData.totalAmount,
          quantity: updateData.quantity,
          occasion: updateData.occasion,
          auctionDate: updateData.auctionDate
        },
        updatedBy: currentUser.username
      };
      
      const logValues = [
        entryId,
        currentUser.id,
        currentUser.username,
        `Entry updated by ${currentUser.username} (${currentUser.role})`,
        totalAmountPaisa,
        'update_entry',
        JSON.stringify(changes),
        new Date().toISOString().split('T')[0],
        new Date().toISOString()
      ];
      
      await pool.query(logSql, logValues);
      console.log("Transaction log created for entry update");
      
      res.json(updatedEntry);
    } catch (error) {
      console.error("Error updating entry:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to update entry" });
    }
  });

  // Entry deletion endpoint (only for admins)
  app.delete("/api/entries/:id", isAdmin, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const user = req.user as any;
      
      // Get the entry first to check if it exists
      const entry = await storage.getEntry(entryId);
      if (!entry) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      // Prevent deleting entries with full payment status
      if (entry.status === PaymentStatus.FULL) {
        return res.status(403).json({ message: "Cannot delete fully paid entries" });
      }
      
      // Delete the entry with transaction logging (who deleted it)
      const result = await storage.deleteEntry(entryId, user.id);
      
      if (result) {
        res.status(200).json({ message: "Entry deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete entry" });
      }
    } catch (error) {
      console.error("Error deleting entry:", error);
      res.status(500).json({ message: "Server error while deleting entry" });
    }
  });
  
  // Transaction logs routes
  app.get("/api/transaction-logs", isAdmin, async (req, res) => {
    try {
      const logs = await storage.getTransactionLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transaction logs" });
    }
  });

  app.get("/api/entries/:id/transaction-logs", isAdmin, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const logs = await storage.getEntryTransactionLogs(entryId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch entry transaction logs" });
    }
  });
  
  // Payment management routes
  // Payment update functionality has been disabled
  app.put("/api/entries/:id/payments/:index", isAdmin, async (req, res) => {
    return res.status(403).json({ message: "Payment update functionality has been disabled" });
  });

  // Endpoint to delete a payment
  app.delete("/api/entries/:id/payments/:index", isAdmin, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const paymentIndex = parseInt(req.params.index);
      const user = req.user as any;
      
      // Get the entry first to check if it exists
      const entryToUpdate = await storage.getEntry(entryId);
      if (!entryToUpdate) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      // Check if payment exists
      if (!entryToUpdate.payments || paymentIndex >= entryToUpdate.payments.length) {
        return res.status(404).json({ message: "Payment record not found" });
      }
      
      // Store the payment to be deleted for logging
      const deletedPayment = entryToUpdate.payments[paymentIndex];
      
      // Remove the payment from the array
      const updatedPayments = [...entryToUpdate.payments];
      updatedPayments.splice(paymentIndex, 1);
      
      // Calculate new received and pending amounts
      const newReceivedAmount = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
      const newPendingAmount = entryToUpdate.totalAmount - newReceivedAmount;
      
      // Determine new payment status
      let newStatus = entryToUpdate.status;
      if (newReceivedAmount === 0) {
        newStatus = PaymentStatus.PENDING;
      } else if (newReceivedAmount < entryToUpdate.totalAmount) {
        newStatus = PaymentStatus.PARTIAL;
      } else {
        newStatus = PaymentStatus.FULL;
      }
      
      // Update the entry with SQL to ensure proper column names
      const { pool } = await import("./db");
      const updateSql = `
        UPDATE entries 
        SET payments = $1, 
            received_amount = $2, 
            pending_amount = $3,
            status = $4
        WHERE id = $5
        RETURNING *
      `;
      
      const updateValues = [
        JSON.stringify(updatedPayments),
        newReceivedAmount,
        newPendingAmount,
        newStatus,
        entryId
      ];
      
      const updateResult = await pool.query(updateSql, updateValues);
      const updatedEntry = updateResult.rows[0];
      
      // Log the deletion with CREDIT transaction type (since we're adding back to the account)
      const logSql = `
        INSERT INTO transaction_logs (
          entry_id, user_id, username, description, 
          amount, transaction_type, details, date, timestamp
        ) VALUES (
          $1, $2, $3, $4, 
          $5, $6, $7, $8, $9
        )
      `;
      
      const logValues = [
        entryId,
        user.id,
        user.username,
        `Deleted payment record of ₹${deletedPayment.amount} from entry #${entryId}`,
        deletedPayment.amount,
        'credit', // Explicitly setting transaction_type to 'credit'
        JSON.stringify({
          date: deletedPayment.date,
          mode: deletedPayment.mode,
          amount: deletedPayment.amount,
          fileUrl: deletedPayment.fileUrl,
          receiptNo: deletedPayment.receiptNo
        }),
        new Date().toISOString().split('T')[0],
        new Date().toISOString()
      ];
      
      await pool.query(logSql, logValues);
      
      // If status has changed, log that too
      if (entryToUpdate.status !== newStatus) {
        const statusLogSql = `
          INSERT INTO transaction_logs (
            entry_id, user_id, username, description, 
            amount, transaction_type, details, date, timestamp
          ) VALUES (
            $1, $2, $3, $4, 
            $5, $6, $7, $8, $9
          )
        `;
        
        const statusLogValues = [
          entryId,
          user.id,
          user.username,
          `Payment status changed from ${entryToUpdate.status} to ${newStatus} after deleting payment`,
          0,
          'update_payment', // Explicitly setting transaction_type
          JSON.stringify({
            oldStatus: entryToUpdate.status,
            newStatus,
            deletedPayment
          }),
          new Date().toISOString().split('T')[0],
          new Date().toISOString()
        ];
        
        await pool.query(statusLogSql, statusLogValues);
      }
      
      // Map the raw DB object to our format
      const mappedEntry = {
        ...updatedEntry,
        userId: updatedEntry.user_id,
        userName: updatedEntry.user_name,
        userMobile: updatedEntry.user_mobile,
        userAddress: updatedEntry.user_address,
        totalAmount: updatedEntry.total_amount,
        pendingAmount: updatedEntry.pending_amount,
        receivedAmount: updatedEntry.received_amount,
        auctionDate: updatedEntry.auction_date,
        updatedAt: updatedEntry.updated_at,
        createdBy: updatedEntry.created_by
      };
      
      res.json(mappedEntry);
    } catch (error) {
      console.error("Error deleting payment:", error);
      res.status(500).json({ message: "Failed to delete payment record" });
    }
  });
  
  // Endpoint to record a payment
  app.post("/api/entries/:id/payments", isAdminOrOperator, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const paymentData = recordPaymentSchema.omit({ entryId: true }).parse(req.body);
      const user = req.user as any;
      
      const entry = await storage.getEntry(entryId);
      if (!entry) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      if (entry.status === PaymentStatus.FULL) {
        return res.status(400).json({ message: "Entry is already fully paid" });
      }
      
      if (paymentData.amount > entry.pendingAmount) {
        return res.status(400).json({ message: "Payment amount exceeds pending amount" });
      }
      
      // Generate unified sequential receipt number based on the year - AM-YYYY-XXXXX
      const receiptNo = await generateUnifiedReceiptNumber(paymentData.date);
      
      // Import pool for database operations
      const { pool } = await import("./db");
      
      // Handle advance payment processing
      if (paymentData.mode === PaymentMode.ADVANCE_PAYMENT) {
        // Verify user has sufficient advance balance
        const availableBalance = await calculateRemainingAdvancePayment(entry.userId);
        if (availableBalance < paymentData.amount) {
          return res.status(400).json({ 
            message: `Insufficient advance balance. Available: ₹${availableBalance.toLocaleString()}, Required: ₹${paymentData.amount.toLocaleString()}` 
          });
        }
        
        // Create advance payment usage record
        const usageSql = `
          INSERT INTO advance_payment_usage (
            user_id, entry_id, amount, date, created_by
          ) VALUES ($1, $2, $3, $4, $5)
        `;
        
        const usageValues = [
          entry.userId,
          entryId,
          paymentData.amount,
          paymentData.date,
          user.username
        ];
        
        await pool.query(usageSql, usageValues);
        console.log(`Created advance payment usage record: User ${entry.userId}, Amount ${paymentData.amount}, Entry ${entryId}`);
      }

      const payment = {
        date: paymentData.date,
        amount: paymentData.amount,
        mode: paymentData.mode || PaymentMode.CASH,
        fileUrl: paymentData.fileUrl,
        receiptNo: receiptNo, // Add unique receipt number
        updatedBy: user.username // Add updatedBy field
      };
      
      // Instead of using storage.recordPayment, we'll implement a direct approach to fix the transaction_type
      // Get the current entry to modify
      const entryToUpdate = await storage.getEntry(entryId);
      if (!entryToUpdate) {
        return res.status(404).json({ message: "Entry not found" });
      }
      
      // Update the entry with the new payment
      const currentPayments = entryToUpdate.payments || [];
      const updatedPayments = [...currentPayments, payment];
      
      // Calculate new received and pending amounts
      const newReceivedAmount = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
      const newPendingAmount = entryToUpdate.totalAmount - newReceivedAmount;
      
      // Determine payment status
      let newStatus = entryToUpdate.status;
      if (newReceivedAmount === 0) {
        newStatus = PaymentStatus.PENDING;
      } else if (newReceivedAmount < entryToUpdate.totalAmount) {
        newStatus = PaymentStatus.PARTIAL;
      } else {
        newStatus = PaymentStatus.FULL;
      }
      
      // Update the entry with SQL to ensure proper column names
      const updateSql = `
        UPDATE entries 
        SET payments = $1, 
            received_amount = $2, 
            pending_amount = $3,
            status = $4
        WHERE id = $5
        RETURNING *
      `;
      
      const updateValues = [
        JSON.stringify(updatedPayments),
        newReceivedAmount,
        newPendingAmount,
        newStatus,
        entryId
      ];
      
      const updateResult = await pool.query(updateSql, updateValues);
      const updatedEntry = updateResult.rows[0];
      
      // Log the payment with DEBIT transaction type
      // Use direct SQL query to ensure transaction_type is correctly set
      const logSql = `
        INSERT INTO transaction_logs (
          entry_id, user_id, username, description, 
          amount, transaction_type, details, date, timestamp
        ) VALUES (
          $1, $2, $3, $4, 
          $5, $6, $7, $8, $9
        )
      `;
      
      const logValues = [
        entryId,
        user.id,
        user.username,
        `Payment of ₹${payment.amount} recorded by ${user.username}`,
        payment.amount,
        'debit', // Explicitly setting transaction_type to 'debit'
        JSON.stringify({
          date: payment.date,
          paymentMode: payment.mode,
          receiptNo: payment.receiptNo
        }),
        new Date().toISOString().split('T')[0],
        new Date().toISOString()
      ];
      
      await pool.query(logSql, logValues);
      
      // If status has changed, log that too
      if (entryToUpdate.status !== newStatus) {
        const statusLogSql = `
          INSERT INTO transaction_logs (
            entry_id, user_id, username, description, 
            amount, transaction_type, details, date, timestamp
          ) VALUES (
            $1, $2, $3, $4, 
            $5, $6, $7, $8, $9
          )
        `;
        
        const statusLogValues = [
          entryId,
          user.id,
          user.username,
          `Payment status changed from ${entryToUpdate.status} to ${newStatus}`,
          0,
          'update_payment', // Explicitly setting transaction_type
          JSON.stringify({
            payment,
            oldStatus: entryToUpdate.status,
            newStatus
          }),
          new Date().toISOString().split('T')[0],
          new Date().toISOString()
        ];
        
        await pool.query(statusLogSql, statusLogValues);
      }
      
      // Convert the response to match our expected schema format
      const mappedEntry = {
        ...updatedEntry,
        userId: updatedEntry.user_id,
        userName: updatedEntry.user_name,
        userMobile: updatedEntry.user_mobile,
        userAddress: updatedEntry.user_address,
        totalAmount: updatedEntry.total_amount,
        pendingAmount: updatedEntry.pending_amount,
        receivedAmount: updatedEntry.received_amount,
        auctionDate: updatedEntry.auction_date,
        updatedAt: updatedEntry.updated_at,
        createdBy: updatedEntry.created_by
      };
      
      // Get the user for whom the payment was recorded
      const entryUser = await storage.getUser(entryToUpdate.userId);
      
      // If user exists, send notification
      if (entryUser) {
        // Import is done inside the handler to avoid circular dependencies
        const { NotificationService } = await import("./notification");
        NotificationService.notifyPaymentRecorded(entryUser, mappedEntry, payment);
        
        // If payment status changed, notify that as well
        if (entryToUpdate.status !== newStatus) {
          NotificationService.notifyPaymentStatusChanged(
            entryUser,
            mappedEntry,
            entryToUpdate.status,
            newStatus
          );
        }
      }
      
      res.json(mappedEntry);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to record payment" });
    }
  });

  // Daily earnings calendar endpoint
  app.get("/api/daily-earnings", isAuthenticated, async (req, res) => {
    try {
      const { year } = req.query;
      const selectedYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      // Get entries from the selected year
      const { pool } = await import("./db");
      
      const sql = `
        SELECT 
          auction_date as date,
          SUM(total_amount) as daily_total
        FROM entries 
        WHERE auction_date LIKE $1
        GROUP BY auction_date
        ORDER BY auction_date
      `;
      
      const result = await pool.query(sql, [`${selectedYear}-%`]);
      
      // Transform data into a format easy to use in the frontend
      const dailyEarnings: { [key: string]: number } = {};
      result.rows.forEach(row => {
        dailyEarnings[row.date] = parseInt(row.daily_total);
      });
      
      console.log(`Daily earnings for ${selectedYear}:`, dailyEarnings);
      
      res.json(dailyEarnings);
    } catch (error) {
      console.error("Error fetching daily earnings:", error);
      res.status(500).json({ message: "Failed to fetch daily earnings data" });
    }
  });

  // Daily payments calendar endpoint
  app.get('/api/daily-payments', isAuthenticated, async (req, res) => {
    try {
      const { year } = req.query;
      const selectedYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      // Get all entries with payments for the selected year
      const entries = await storage.getEntries();
      
      // Extract payment records and group by payment date
      const dailyPayments: { [key: string]: number } = {};
      
      entries.forEach(entry => {
        if (entry.payments && entry.payments.length > 0) {
          entry.payments.forEach(payment => {
            // Check if payment date is in the selected year
            if (payment.date.startsWith(selectedYear.toString())) {
              if (!dailyPayments[payment.date]) {
                dailyPayments[payment.date] = 0;
              }
              dailyPayments[payment.date] += payment.amount;
            }
          });
        }
      });
      
      console.log(`Daily payments for ${selectedYear}:`, dailyPayments);
      
      res.json(dailyPayments);
    } catch (error) {
      console.error("Error fetching daily payments:", error);
      res.status(500).json({ message: "Failed to fetch daily payments data" });
    }
  });

  // Dashboard summary route with date range filtering - restricted to admin/operator only
  app.get("/api/dashboard", isAdminOrOperator, async (req, res) => {
    try {
      const user = req.user as any;
      const { startDate, endDate } = req.query;
      
      // Only admin and operator can access dashboard data
      const entries = await storage.getEntries();
      
      // Filter entries by date range if provided
      let filteredEntries = entries;
      if (startDate || endDate) {
        filteredEntries = entries.filter(entry => {
          const entryDate = new Date(entry.auctionDate);
          const start = startDate ? new Date(startDate as string) : null;
          const end = endDate ? new Date((endDate as string) + ' 23:59:59') : null;
          
          return (!start || entryDate >= start) && (!end || entryDate <= end);
        });
      }
      
      const totalAmount = filteredEntries.reduce((sum, entry) => sum + entry.totalAmount, 0);
      const receivedAmount = filteredEntries.reduce((sum, entry) => sum + entry.receivedAmount, 0);
      const pendingAmount = filteredEntries.reduce((sum, entry) => sum + entry.pendingAmount, 0);
      
      const pendingEntries = filteredEntries.filter(entry => entry.status === PaymentStatus.PENDING).length;
      const partialEntries = filteredEntries.filter(entry => entry.status === PaymentStatus.PARTIAL).length;
      const completedEntries = filteredEntries.filter(entry => entry.status === PaymentStatus.FULL).length;
      
      // Get remaining advance payments (only for admin/operator, viewers get 0)
      let totalAdvancePayments = 0;
      if (user.role === "admin" || user.role === "operator") {
        try {
          const { pool } = await import("./db");
          
          // Get all users with advance payments (don't filter by date - we want all users with any advance payments)
          const usersWithAdvance = await pool.query(`
            SELECT DISTINCT user_id FROM advance_payments
          `);
          
          // Calculate remaining balance for each user
          for (const userRow of usersWithAdvance.rows) {
            const remainingBalance = await calculateRemainingAdvancePayment(userRow.user_id);
            // Only add positive balances (users can't have negative advance balances)
            if (remainingBalance > 0) {
              totalAdvancePayments += remainingBalance;
            }
          }
          
          console.log("Dashboard advance payments calculation:", {
            usersChecked: usersWithAdvance.rows.length,
            totalAdvancePayments
          });
        } catch (error) {
          console.error("Error calculating advance payments for dashboard:", error);
          totalAdvancePayments = 0; // Set to 0 if there's an error
        }
      }
      
      // Sort entries by date (most recent first)
      const recentActivity = [...entries]
        .sort((a, b) => new Date(b.auctionDate).getTime() - new Date(a.auctionDate).getTime())
        .slice(0, 5);
      
      // Get corpus settings for overall summary calculation
      let corpusValue = 0;
      try {
        const corpusResult = await pool.query('SELECT corpus_value FROM corpus_settings LIMIT 1');
        corpusValue = corpusResult.rows[0]?.corpus_value || 0;
      } catch (error) {
        console.log("No corpus settings found, using default value 0");
      }

      // Get total expenses (unfiltered by date range)
      let totalExpenses = 0;
      try {
        const expensesResult = await pool.query('SELECT SUM(amount) as total FROM expense_entries');
        totalExpenses = parseInt(expensesResult.rows[0]?.total) || 0;
      } catch (error) {
        console.error("Error calculating total expenses:", error);
      }

      // Get total received outstanding payments from all users
      let totalReceivedOutstanding = 0;
      try {
        const { pool } = await import("./db");
        const result = await pool.query(`
          SELECT COALESCE(SUM(received_amount), 0) as total_received_outstanding
          FROM previous_outstanding_records
        `);
        totalReceivedOutstanding = parseInt(result.rows[0].total_received_outstanding) || 0;
      } catch (error) {
        console.error("Error calculating received outstanding:", error);
        totalReceivedOutstanding = 0;
      }

      // Calculate cash in bank: ₹139,084 + ₹4,831 + ₹43,231 - ₹7,284 + Total Received Outstanding Payment
      // Expenses are stored in paisa, need to convert to rupees for calculation
      const cashInBank = corpusValue + receivedAmount + totalAdvancePayments - Math.round(totalExpenses / 100) + totalReceivedOutstanding;

      res.json({
        summary: {
          totalAmount,
          receivedAmount,
          pendingAmount,
          pendingEntries,
          partialEntries,
          completedEntries,
          totalAdvancePayments
        },
        overallSummary: {
          corpusValue,
          totalReceived: receivedAmount,
          totalAdvancePayments,
          totalExpenses,
          totalReceivedOutstanding,
          cashInBank
        },
        recentActivity
      });
    } catch (error) {
      console.error("Dashboard error:", error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ message: "Failed to fetch dashboard data", error: errorMessage });
    }
  });

  // Database backup API - only for operators and admins
  app.post("/api/database/backup", isAdminOrOperator, async (req, res) => {
    try {
      const currentUser = req.user as any;
      console.log(`Database backup requested by ${currentUser.username} (${currentUser.role})`);
      
      const xlsx = await import("xlsx");
      const nodemailer = await import("nodemailer");
      const path = await import("path");
      const fs = await import("fs");
      const { pool } = await import("./db");
      
      // Create workbook
      const workbook = xlsx.utils.book_new();
      
      // Get all tables data with correct column names
      const tables = [
        { name: "Users", query: "SELECT id, username, name, email, mobile, address, role, status FROM users ORDER BY id" },
        { name: "Boli_Entries", query: "SELECT id, user_id, user_name, user_mobile, description, amount, quantity, total_amount, occasion, auction_date as boli_date, received_amount, pending_amount, status, created_by FROM entries ORDER BY id" },
        { name: "Advance_Payments", query: "SELECT id, user_id, user_name, user_mobile, date, amount, payment_mode, receipt_no, created_by FROM advance_payments ORDER BY id" },
        { name: "Dravya_Entries", query: "SELECT id, user_id, user_name, description, occasion, created_by FROM dravya_entries ORDER BY id" },
        { name: "Expense_Entries", query: "SELECT id, description, amount, quantity, reason, expense_date, payment_mode, approved_by, created_by, updated_at FROM expense_entries ORDER BY id" },
        { name: "Transaction_Logs", query: "SELECT id, entry_id, user_id, username, description, amount, transaction_type, date, timestamp FROM transaction_logs ORDER BY id" }
      ];
      
      // Export each table as a worksheet
      for (const table of tables) {
        try {
          const result = await pool.query(table.query);
          const worksheet = xlsx.utils.json_to_sheet(result.rows);
          xlsx.utils.book_append_sheet(workbook, worksheet, table.name);
          console.log(`Exported ${result.rows.length} rows from ${table.name}`);
        } catch (tableError) {
          console.error(`Error exporting ${table.name}:`, tableError);
          // Create empty sheet for failed table
          const emptySheet = xlsx.utils.json_to_sheet([{ error: `Failed to export ${table.name}` }]);
          xlsx.utils.book_append_sheet(workbook, emptySheet, table.name);
        }
      }
      
      // Generate filename with timestamp
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
      const filename = `Database_Backup_${timestamp}.xlsx`;
      const filepath = path.join(process.cwd(), 'uploads', filename);
      
      // Write Excel file
      xlsx.writeFile(workbook, filepath);
      console.log(`Backup file created: ${filename}`);
      
      // Get all operators for email distribution
      const operatorResult = await pool.query(
        "SELECT email, name FROM users WHERE role IN ('operator', 'admin') AND email IS NOT NULL AND email != ''"
      );
      
      if (operatorResult.rows.length === 0) {
        return res.status(400).json({ message: "No operators with valid email addresses found" });
      }
      
      // Check if SendGrid API key is available
      if (!process.env.SENDGRID_API_KEY) {
        console.log("SendGrid API key not found, skipping email sending");
        return res.json({ 
          message: "Database backup created successfully. Email functionality requires SendGrid API key.",
          filename,
          operatorCount: operatorResult.rows.length,
          downloadUrl: `/uploads/${filename}`
        });
      }
      
      // Configure nodemailer with SendGrid
      const transporter = nodemailer.createTransport({
        host: 'smtp.sendgrid.net',
        port: 587,
        secure: false,
        auth: {
          user: 'apikey',
          pass: process.env.SENDGRID_API_KEY
        }
      });
      
      // Email configuration
      const emailOptions = {
        from: 'noreply@shivnagarjaintemple.org',
        subject: `Database Backup - ${new Date().toLocaleDateString('en-IN')}`,
        html: `
          <h2>श्री शिवनगर जैन मंदिर समिति - Database Backup</h2>
          <p>Dear Temple Administrator,</p>
          <p>A database backup has been automatically generated and is attached to this email.</p>
          
          <h3>Backup Details:</h3>
          <ul>
            <li><strong>Generated by:</strong> ${currentUser.name} (${currentUser.username})</li>
            <li><strong>Date & Time:</strong> ${new Date().toLocaleString('en-IN')}</li>
            <li><strong>File Size:</strong> ${Math.round(fs.statSync(filepath).size / 1024)} KB</li>
          </ul>
          
          <h3>Included Data:</h3>
          <ul>
            <li>Users Management</li>
            <li>Boli Entries & Payments</li>
            <li>Advance Payments</li>
            <li>Dravya Entries</li>
            <li>Expense Entries</li>
            <li>Transaction Logs</li>
          </ul>
          
          <p><strong>Note:</strong> Please store this backup file securely and delete it from your email after downloading.</p>
          <p>This is an automated email from the Temple Management System.</p>
          
          <hr>
          <small>श्री शिवनगर जैन मंदिर समिति, शिवनगर, जबलपुर</small>
        `,
        attachments: [{
          filename: filename,
          path: filepath
        }]
      };
      
      // Send email to all operators
      const emailPromises = operatorResult.rows.map(operator => 
        transporter.sendMail({
          ...emailOptions,
          to: operator.email,
          html: emailOptions.html.replace('Dear Temple Administrator', `Dear ${operator.name}`)
        })
      );
      
      await Promise.all(emailPromises);
      console.log(`Backup email sent to ${operatorResult.rows.length} operators`);
      
      // Clean up the file after sending
      setTimeout(() => {
        try {
          fs.unlinkSync(filepath);
          console.log(`Backup file ${filename} cleaned up`);
        } catch (cleanupError) {
          console.error("Error cleaning up backup file:", cleanupError);
        }
      }, 300000); // Delete after 5 minutes
      
      res.json({
        message: `Database backup created and emailed to ${operatorResult.rows.length} operators successfully`,
        filename,
        operatorCount: operatorResult.rows.length,
        operatorEmails: operatorResult.rows.map(op => op.email),
        downloadUrl: `/uploads/${filename}`
      });
      
    } catch (error) {
      console.error("Database backup error:", error);
      res.status(500).json({ 
        message: "Failed to create database backup",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Previous Outstanding Records API routes
  app.get("/api/previous-outstanding", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { userId } = req.query;
      
      let records;
      if (userId) {
        records = await db.select().from(previousOutstandingRecords)
          .where(eq(previousOutstandingRecords.userId, parseInt(userId as string)));
      } else {
        records = await db.select().from(previousOutstandingRecords);
      }
      
      // For each record, calculate payment totals
      const recordsWithPayments = records.map((record) => {
        const payments = record.payments || [];
        const receivedAmount = payments.reduce((sum: number, payment: any) => sum + payment.amount, 0);
        const pendingAmount = Math.max(0, record.outstandingAmount - receivedAmount);
        
        // Determine status
        let status: 'pending' | 'partial' | 'full' = 'pending';
        if (receivedAmount >= record.outstandingAmount) {
          status = 'full';
        } else if (receivedAmount > 0) {
          status = 'partial';
        }
        
        return {
          ...record,
          receivedAmount,
          pendingAmount,
          status
        };
      });
      
      res.json(recordsWithPayments);
    } catch (error) {
      console.error("Error fetching previous outstanding records:", error);
      res.status(500).json({ message: "Failed to fetch previous outstanding records" });
    }
  });

  // Get single previous outstanding record
  app.get("/api/previous-outstanding/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const recordId = parseInt(req.params.id);
      
      const [record] = await db.select().from(previousOutstandingRecords)
        .where(eq(previousOutstandingRecords.id, recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Previous outstanding record not found" });
      }
      
      // Calculate totals from existing payments array
      const payments = record.payments || [];
      const receivedAmount = payments.reduce((sum: number, payment: any) => sum + payment.amount, 0);
      const pendingAmount = Math.max(0, record.outstandingAmount - receivedAmount);
      
      // Determine status
      let status: 'pending' | 'partial' | 'full' = 'pending';
      if (receivedAmount >= record.outstandingAmount) {
        status = 'full';
      } else if (receivedAmount > 0) {
        status = 'partial';
      }
      
      const result = {
        ...record,
        receivedAmount,
        pendingAmount,
        status,
        payments: payments.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())
      };
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching previous outstanding record:", error);
      res.status(500).json({ message: "Failed to fetch previous outstanding record" });
    }
  });

  // Record payment for previous outstanding record
  app.post("/api/previous-outstanding/:id/payment", isAuthenticated, upload.single('paymentFile'), async (req: Request, res: Response) => {
    try {
      const recordId = parseInt(req.params.id);
      const { amount, date, mode, receiptNo } = req.body;
      const user = req.user as any;
      
      if (!amount || !date || !mode) {
        return res.status(400).json({ message: "Amount, date, and payment mode are required" });
      }
      
      // Verify record exists
      const [record] = await db.select().from(previousOutstandingRecords)
        .where(eq(previousOutstandingRecords.id, recordId));
      
      if (!record) {
        return res.status(404).json({ message: "Previous outstanding record not found" });
      }
      
      // Calculate current totals from existing payments array
      const existingPayments = record.payments || [];
      const totalReceived = existingPayments.reduce((sum: number, payment: any) => sum + payment.amount, 0);
      const amountToAdd = parseInt(amount);
      
      if (totalReceived + amountToAdd > record.outstandingAmount) {
        return res.status(400).json({ 
          message: `Payment amount exceeds remaining balance. Remaining: ₹${(record.outstandingAmount - totalReceived) / 100}` 
        });
      }
      
      let fileUrl = null;
      if (req.file) {
        // Save file and get URL
        fileUrl = `/uploads/${req.file.filename}`;
      }
      
      // Create new payment record
      const newPayment = {
        date,
        amount: amountToAdd,
        mode,
        receiptNo: receiptNo || undefined,
        fileUrl: fileUrl || undefined,
        updatedBy: user.name
      };
      
      // Add payment to existing payments array
      const updatedPayments = [...existingPayments, newPayment];
      
      // Calculate updated totals
      const newTotalReceived = totalReceived + amountToAdd;
      const newPendingAmount = record.outstandingAmount - newTotalReceived;
      
      // Determine status
      let newStatus: 'pending' | 'partial' | 'full';
      if (newPendingAmount <= 0) {
        newStatus = 'full';
      } else if (newTotalReceived > 0) {
        newStatus = 'partial';
      } else {
        newStatus = 'pending';
      }
      
      // Update the record with new payment and calculated values
      await db.update(previousOutstandingRecords)
        .set({ 
          payments: updatedPayments,
          receivedAmount: newTotalReceived,
          pendingAmount: Math.max(0, newPendingAmount),
          status: newStatus,
          updatedAt: new Date().toISOString() 
        })
        .where(eq(previousOutstandingRecords.id, recordId));
      
      res.json({ message: "Payment recorded successfully", payment: newPayment });
    } catch (error) {
      console.error("Error recording payment:", error);
      res.status(500).json({ message: "Failed to record payment" });
    }
  });

  app.post("/api/previous-outstanding", isAdminOrOperator, upload.single('attachmentFile'), async (req: Request, res: Response) => {
    try {
      const { userId, userName, userMobile, userAddress, outstandingAmount, description, createdBy } = req.body;
      
      // Debug logging
      console.log("Raw request body:", req.body);
      console.log("Parsed values:", { userId, userName, userMobile, userAddress, outstandingAmount, description, createdBy });
      
      // Validate required fields
      const validationData = {
        userId: parseInt(userId) || 0,
        userName: userName || '',
        userMobile: userMobile || '',
        userAddress: userAddress || '',
        outstandingAmount: parseInt(outstandingAmount) || 0, // Already in paisa
        description: description || 'Previous Outstanding Amount',
        createdBy: createdBy || 'system'
      };
      
      console.log("Validation data:", validationData);

      const validatedData = insertPreviousOutstandingRecordSchema.parse(validationData);

      // Handle file upload
      let attachmentUrl = null;
      let attachmentName = null;
      
      if (req.file) {
        const uploadDir = path.join(process.cwd(), 'uploads');
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }
        
        const filename = `previous-outstanding-${Date.now()}-${req.file.originalname}`;
        const filepath = path.join(uploadDir, filename);
        
        fs.renameSync(req.file.path, filepath);
        attachmentUrl = `/uploads/${filename}`;
        attachmentName = req.file.originalname;
      }

      // Create record
      const [record] = await db.insert(previousOutstandingRecords).values({
        ...validatedData,
        attachmentUrl,
        attachmentName
      }).returning();

      console.log(`Previous outstanding record created: ₹${validationData.outstandingAmount/100} for user ${validationData.userName} by ${validationData.createdBy}`);
      res.json(record);
    } catch (error) {
      console.error("Error creating previous outstanding record:", error);
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create previous outstanding record" });
    }
  });

  // Record payment for previous outstanding record
  app.post("/api/previous-outstanding/:id/payment", isAdminOrOperator, upload.single('paymentFile'), async (req: Request, res: Response) => {
    try {
      const recordId = parseInt(req.params.id);
      const { amount, date, mode, receiptNo } = req.body;
      const user = req.user as any;

      // Validate payment data
      const paymentData = {
        entryId: recordId,
        amount: parseInt(amount),
        date,
        mode,
        receiptNo: receiptNo || undefined
      };

      const validatedPayment = recordPaymentSchema.parse(paymentData);

      // Get the previous outstanding record
      const [record] = await db.select().from(previousOutstandingRecords)
        .where(eq(previousOutstandingRecords.id, recordId));

      if (!record) {
        return res.status(404).json({ message: "Previous outstanding record not found" });
      }

      // Handle file upload
      let fileUrl = null;
      if (req.file) {
        fileUrl = `/uploads/${req.file.filename}`;
      }

      // Create payment record
      const newPayment = {
        date: validatedPayment.date,
        amount: validatedPayment.amount,
        mode: validatedPayment.mode,
        fileUrl: fileUrl || undefined,
        receiptNo: validatedPayment.receiptNo,
        updatedBy: user.username
      };

      // Update the record with new payment
      const updatedPayments = [...(record.payments || []), newPayment];
      const newReceivedAmount = record.receivedAmount + validatedPayment.amount;
      const newPendingAmount = record.outstandingAmount - newReceivedAmount;
      
      // Determine payment status
      let status: PaymentStatusType;
      if (newPendingAmount <= 0) {
        status = PaymentStatus.FULL;
      } else if (newReceivedAmount > 0) {
        status = PaymentStatus.PARTIAL;
      } else {
        status = PaymentStatus.PENDING;
      }

      // Update the record
      await db.update(previousOutstandingRecords)
        .set({
          payments: updatedPayments,
          receivedAmount: newReceivedAmount,
          pendingAmount: Math.max(0, newPendingAmount),
          status: status,
          updatedAt: new Date().toISOString()
        })
        .where(eq(previousOutstandingRecords.id, recordId));

      res.json({ 
        message: "Payment recorded successfully",
        payment: newPayment,
        updatedRecord: {
          id: recordId,
          receivedAmount: newReceivedAmount,
          pendingAmount: Math.max(0, newPendingAmount),
          status: status
        }
      });
    } catch (error) {
      console.error("Error recording payment:", error);
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to record payment" });
    }
  });

  // Download route for differential Excel files
  app.get("/api/download/:filename", (req, res) => {
    try {
      const filename = req.params.filename;
      const filepath = path.join(process.cwd(), filename);
      
      // Security check - only allow specific files
      const allowedFiles = [
        'Address_Differential_Users.xlsx',
        'Missing_Users_Differential.xlsx',
        'Address_Mobile_Differential_Users.xlsx',
        'Duplicate_Mobile_Users_2025-08-09.xlsx'
      ];
      
      if (!allowedFiles.includes(filename)) {
        return res.status(404).json({ message: "File not found" });
      }
      
      if (!fs.existsSync(filepath)) {
        return res.status(404).json({ message: "File not found" });
      }
      
      // Set appropriate headers for Excel download
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      // Stream the file
      const fileStream = fs.createReadStream(filepath);
      fileStream.pipe(res);
      
    } catch (error) {
      console.error("Error serving download:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  // Corpus Settings API endpoints (Admin only)
  app.get("/api/corpus-settings", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Only allow admin access
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Access denied. Admin role required." });
      }
      
      const [settings] = await db.select().from(corpusSettings).limit(1);
      
      // Return default values if no settings exist
      if (!settings) {
        return res.json({
          corpusValue: 0,
          baseDate: "2025-07-31",
          updatedAt: null,
          updatedBy: null
        });
      }
      
      res.json(settings);
    } catch (error) {
      console.error("Error fetching corpus settings:", error);
      res.status(500).json({ message: "Failed to fetch corpus settings" });
    }
  });

  app.post("/api/corpus-settings", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Only allow admin access
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Access denied. Admin role required." });
      }
      
      const validatedData = insertCorpusSettingsSchema.parse({
        ...req.body,
        corpusValue: req.body.corpusValue, // Keep as rupees
        updatedBy: user.username
      });
      
      // Check if settings already exist
      const [existingSettings] = await db.select().from(corpusSettings).limit(1);
      
      let result;
      if (existingSettings) {
        // Update existing settings
        [result] = await db.update(corpusSettings)
          .set(validatedData)
          .where(eq(corpusSettings.id, existingSettings.id))
          .returning();
      } else {
        // Create new settings
        [result] = await db.insert(corpusSettings).values(validatedData).returning();
      }
      
      console.log(`Corpus settings updated by ${user.username}: ₹${req.body.corpusValue} as of ${validatedData.baseDate}`);
      res.json(result);
    } catch (error) {
      console.error("Error updating corpus settings:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to update corpus settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
