import {
  users, entries, transactionLogs,
  type User, type InsertUser,
  type Entry, type InsertEntry,
  type PaymentRecord, type UserRoleType, type PaymentStatusType,
  PaymentStatus, UserRole, TransactionType, type TransactionTypeValue,
  type TransactionLog, type InsertTransactionLog
} from "@shared/schema";
import { db } from "./db";
import { eq, and, SQL, desc } from "drizzle-orm";

export interface IStorage {
  // User management
  getUsers(): Promise<User[]>;
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByMobile(mobile: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Entry management
  getEntries(): Promise<Entry[]>;
  getEntry(id: number): Promise<Entry | undefined>;
  getUserEntries(userId: number): Promise<Entry[]>;
  getEntriesByUserId(userId: number): Promise<Entry[]>;
  createEntry(entry: InsertEntry, createdByUserId: number): Promise<Entry>;
  updateEntry(id: number, updates: Partial<Entry>, updatedByUserId: number): Promise<Entry | undefined>;
  deleteEntry(id: number, deletedByUserId: number): Promise<boolean>;
  
  // Advance payment management
  getAdvancePayments(): Promise<any[]>;
  getAdvancePaymentsByUserId(userId: number): Promise<any[]>;
  calculateRemainingAdvancePayment(userId: number): Promise<number>;
  
  // Dravya entry management
  getDravyaEntries(): Promise<any[]>;
  getDravyaEntriesByUserId(userId: number): Promise<any[]>;
  
  // Payment management
  recordPayment(entryId: number, payment: PaymentRecord, recordedByUserId: number): Promise<Entry | undefined>;
  deletePayment(entryId: number, paymentIndex: number, deletedByUserId: number): Promise<Entry | undefined>;
  
  // Transaction logging
  getTransactionLogs(): Promise<TransactionLog[]>;
  getEntryTransactionLogs(entryId: number): Promise<TransactionLog[]>;
  createTransactionLog(log: InsertTransactionLog): Promise<TransactionLog>;
}

// Function to generate sequential receipt numbers based on year
export async function generateReceiptNumber(paymentDate: string): Promise<string> {
  try {
    const year = paymentDate.split('-')[0]; // Extract year from YYYY-MM-DD
    
    // Find all logs for this year that have receipt numbers
    const logs = await db.select()
      .from(transactionLogs)
      .where(and(
        // SQL string contains operation - checking for receipt numbers with this year
        // e.g., "details" containing "AM-2025-"
        eq(transactionLogs.transactionType, TransactionType.DEBIT)
      ))
      .orderBy(desc(transactionLogs.id))
      .limit(100);
    
    let sequenceNumber = 1; // Default starting number
    
    // Loop through logs to find the latest receipt number for this year
    for (const log of logs) {
      if (!log.details) continue;
      
      const details = typeof log.details === 'string' 
        ? JSON.parse(log.details) 
        : log.details;
      
      // Skip if no receipt number in details
      if (!details.receiptNo) continue;
      
      // Check if this receipt number matches our format and year
      if (typeof details.receiptNo === 'string' && 
          details.receiptNo.startsWith(`AM-${year}-`)) {
        
        // Extract sequence number
        const match = details.receiptNo.match(/AM-\d{4}-(\d{5})/);
        if (match && match[1]) {
          const foundNumber = parseInt(match[1], 10);
          // Take the highest number we find
          if (!isNaN(foundNumber) && foundNumber >= sequenceNumber) {
            sequenceNumber = foundNumber + 1;
          }
        }
      }
    }
    
    // Format with 5 digits (00001, 00002, etc.)
    const formattedNumber = sequenceNumber.toString().padStart(5, '0');
    return `AM-${year}-${formattedNumber}`;
  } catch (error) {
    console.error("Error generating receipt number:", error);
    // Fallback to a timestamp-based format if there's an error
    const timestamp = new Date().getTime();
    return `AM-${paymentDate.split('-')[0]}-${timestamp.toString().slice(-5)}`;
  }
}

export class DatabaseStorage implements IStorage {
  async getTransactionLogs(): Promise<TransactionLog[]> {
    try {
      return await db.select().from(transactionLogs).orderBy(desc(transactionLogs.id));
    } catch (error) {
      console.error("Error fetching transaction logs:", error);
      return []; // Return empty array instead of failing
    }
  }
  
  async getEntryTransactionLogs(entryId: number): Promise<TransactionLog[]> {
    try {
      return await db
        .select()
        .from(transactionLogs)
        .where(eq(transactionLogs.entryId, entryId))
        .orderBy(desc(transactionLogs.id));
    } catch (error) {
      console.error(`Error fetching transaction logs for entry ${entryId}:`, error);
      return []; // Return empty array instead of failing
    }
  }
  
  async createTransactionLog(log: InsertTransactionLog): Promise<TransactionLog> {
    try {
      // Ensure we have a valid transaction type
      const transactionType = log.transactionType || TransactionType.UPDATE_ENTRY;
      
      const [result] = await db.insert(transactionLogs).values({
        entryId: log.entryId || 0,
        userId: log.userId || 0,
        username: log.username || 'system',
        description: log.description || 'Transaction record',
        amount: log.amount || 0,
        transactionType: transactionType,
        details: JSON.stringify(log.details || {}),
        date: new Date().toISOString().split('T')[0],
        timestamp: new Date().toISOString()
      }).returning();
      
      return result;
    } catch (error) {
      console.error("Error creating transaction log:", error);
      throw error;
    }
  }

  async getUsers(): Promise<User[]> {
    try {
      return await db.select().from(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      return []; // Return empty array instead of failing
    }
  }
  
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error(`Error fetching user ${id}:`, error);
      return undefined;
    }
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.username, username));
      return user;
    } catch (error) {
      console.error(`Error fetching user by username ${username}:`, error);
      return undefined;
    }
  }
  
  async getUserByMobile(mobile: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.mobile, mobile));
      return user;
    } catch (error) {
      console.error(`Error fetching user by mobile ${mobile}:`, error);
      return undefined;
    }
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      // Ensure default values
      const userRole: UserRoleType = insertUser.role as UserRoleType || UserRole.VIEWER;
      
      // Get the next serial number based on existing users
      const allUsers = await db.select().from(users);
      const nextSerialNumber = allUsers.length + 1;
      
      const [newUser] = await db.insert(users).values({
        ...insertUser,
        role: userRole,
        serialNumber: nextSerialNumber
      }).returning();
      
      return newUser;
    } catch (error) {
      console.error("Error creating user:", error);
      throw error;
    }
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set(updates)
        .where(eq(users.id, id))
        .returning();
      
      return updatedUser;
    } catch (error) {
      console.error(`Error updating user ${id}:`, error);
      return undefined;
    }
  }

  async getEntries(): Promise<Entry[]> {
    try {
      const entriesData = await db.select({
        entry: entries,
        user: users
      })
      .from(entries)
      .leftJoin(users, eq(entries.userId, users.id))
      .orderBy(entries.id); // Add explicit ordering by ID
      
      // Merge user information from users table to entries
      return entriesData.map(item => ({
        ...item.entry,
        userName: item.user?.name || item.entry.userName,
        userMobile: item.user?.mobile || item.entry.userMobile,
        userAddress: item.user?.address || item.entry.userAddress
      }));
    } catch (error) {
      console.error("Error fetching entries:", error);
      return []; // Return empty array instead of failing
    }
  }
  
  async getEntry(id: number): Promise<Entry | undefined> {
    try {
      const entryData = await db.select({
        entry: entries,
        user: users
      })
      .from(entries)
      .leftJoin(users, eq(entries.userId, users.id))
      .where(eq(entries.id, id));
      
      if (entryData.length === 0) return undefined;
      
      // Merge user information from users table to entry
      return {
        ...entryData[0].entry,
        userName: entryData[0].user?.name || entryData[0].entry.userName,
        userMobile: entryData[0].user?.mobile || entryData[0].entry.userMobile,
        userAddress: entryData[0].user?.address || entryData[0].entry.userAddress
      };
    } catch (error) {
      console.error(`Error fetching entry ${id}:`, error);
      return undefined;
    }
  }
  
  async getUserEntries(userId: number): Promise<Entry[]> {
    try {
      const entriesData = await db.select({
        entry: entries,
        user: users
      })
      .from(entries)
      .leftJoin(users, eq(entries.userId, users.id))
      .where(eq(entries.userId, userId));
      
      // Merge user information from users table to entries
      return entriesData.map(item => ({
        ...item.entry,
        userName: item.user?.name || item.entry.userName,
        userMobile: item.user?.mobile || item.entry.userMobile,
        userAddress: item.user?.address || item.entry.userAddress
      }));
    } catch (error) {
      console.error(`Error fetching entries for user ${userId}:`, error);
      return []; // Return empty array instead of failing
    }
  }

  async createEntry(insertEntry: InsertEntry, createdByUserId?: number): Promise<Entry> {
    try {
      console.log("Creating entry with data:", insertEntry);
      
      const quantity = insertEntry.quantity || 1;
      const totalAmount = insertEntry.amount * quantity;
      
      // Get the current user data to ensure we have the latest information
      const userResult = await db.select().from(users).where(eq(users.id, insertEntry.userId));
      const user = userResult.length > 0 ? userResult[0] : null;
      
      console.log("User found for entry:", user);
      
      // Execute raw SQL query with exact column names to match the database
      const sql = `
        INSERT INTO entries (
          user_id, user_name, user_mobile, user_address, 
          description, amount, quantity, total_amount, 
          occasion, auction_date, pending_amount, received_amount, 
          status, payments, created_by
        ) VALUES (
          $1, $2, $3, $4, 
          $5, $6, $7, $8, 
          $9, $10, $11, $12, 
          $13, $14, $15
        ) RETURNING *
      `;
      
      const values = [
        insertEntry.userId,
        user?.name || insertEntry.userName || 'Unknown User',
        user?.mobile || '',
        user?.address || '',
        insertEntry.description || '',
        insertEntry.amount,
        quantity,
        totalAmount,
        insertEntry.occasion || '',
        insertEntry.auctionDate || new Date().toISOString().split('T')[0],
        totalAmount,
        0,
        PaymentStatus.PENDING,
        '[]',
        createdByUserId ? 'operator' : 'system'
      ];
      
      console.log("Executing SQL with values:", values);
      
      const { pool } = await import("./db");
      const result = await pool.query(sql, values);
      console.log("Entry creation result:", result.rows[0]);
      
      const newEntry = result.rows[0];
      
      // Log this entry creation as a CREDIT transaction if we have the creator's ID
      if (createdByUserId && newEntry) {
        // Get the user who created the entry
        const creatorResult = await db.select().from(users).where(eq(users.id, createdByUserId));
        const creator = creatorResult.length > 0 ? creatorResult[0] : null;
        
        if (creator) {
          try {
            await this.createTransactionLog({
              entryId: newEntry.id,
              userId: createdByUserId,
              username: creator.username,
              description: `Created new entry: "${newEntry.description}"`,
              amount: newEntry.totalAmount,
              transactionType: TransactionType.CREDIT,
              details: newEntry
            });
          } catch (logError) {
            console.error("Error logging transaction:", logError);
            // Continue anyway so entry creation succeeds
          }
        }
      }
      
      // Convert the response to match our expected schema format
      return {
        ...newEntry,
        userId: newEntry.user_id,
        userName: newEntry.user_name,
        userMobile: newEntry.user_mobile,
        userAddress: newEntry.user_address,
        totalAmount: newEntry.totalAmount,
        pendingAmount: newEntry.pending_amount,
        receivedAmount: newEntry.received_amount,
        auctionDate: newEntry.auction_date,
        updatedAt: newEntry.updated_at,
        createdBy: newEntry.created_by
      };
    } catch (error) {
      console.error("Error in createEntry:", error);
      throw error;
    }
  }

  async updateEntry(id: number, updates: Partial<Entry>, updatedByUserId: number): Promise<Entry | undefined> {
    try {
      // Get the original entry first
      const [originalEntry] = await db.select().from(entries).where(eq(entries.id, id));
      if (!originalEntry) return undefined;
      
      // Get the user who is updating this entry
      const [updater] = await db.select().from(users).where(eq(users.id, updatedByUserId));
      if (!updater) return undefined;
      
      // Calculate new values
      const newAmount = updates.amount !== undefined ? updates.amount : originalEntry.amount;
      const newQuantity = updates.quantity !== undefined ? updates.quantity : originalEntry.quantity;
      const newTotal = newAmount * newQuantity;
      const newPendingAmount = newTotal - originalEntry.receivedAmount;
      
      // Update the entry with snake_case field names to match DB
      const [updatedEntry] = await db
        .update(entries)
        .set({
          description: updates.description || originalEntry.description,
          amount: newAmount,
          quantity: newQuantity,
          total_amount: newTotal,
          pending_amount: newPendingAmount,
          occasion: updates.occasion || originalEntry.occasion,
          auction_date: updates.auctionDate || originalEntry.auctionDate,
          updated_at: new Date().toISOString()
        })
        .where(eq(entries.id, id))
        .returning();
        
      if (!updatedEntry) return undefined;
      
      // Removed transaction logging for entry updates to prevent errors
      
      return updatedEntry;
    } catch (error) {
      console.error(`Error updating entry ${id}:`, error);
      return undefined;
    }
  }
  
  async deleteEntry(id: number, deletedByUserId: number): Promise<boolean> {
    try {
      // Get the entry first to log the deletion
      const [entry] = await db.select().from(entries).where(eq(entries.id, id));
      if (!entry) return false;
      
      // Get the user who is deleting this entry
      const [deleter] = await db.select().from(users).where(eq(users.id, deletedByUserId));
      if (!deleter) return false;
      
      // Log this as a DEBIT transaction (canceling the original CREDIT)
      await this.createTransactionLog({
        entryId: entry.id,
        userId: deletedByUserId,
        username: deleter.username,
        description: `Deleted entry #${entry.id}`,
        amount: entry.totalAmount,
        transactionType: TransactionType.DEBIT,
        details: entry
      });
      
      // Delete the entry
      await db
        .delete(entries)
        .where(eq(entries.id, id));
      
      return true;
    } catch (error) {
      console.error(`Error deleting entry ${id}:`, error);
      return false;
    }
  }
  
  async deletePayment(entryId: number, paymentIndex: number, deletedByUserId: number): Promise<Entry | undefined> {
    try {
      // Get the entry to modify its payments
      const entryResult = await db.select({
        entry: entries,
        user: users
      })
      .from(entries)
      .leftJoin(users, eq(entries.userId, users.id))
      .where(eq(entries.id, entryId));
      
      if (entryResult.length === 0) return undefined;
      
      const entry = entryResult[0].entry;
      const user = entryResult[0].user;
      
      if (!entry.payments || paymentIndex >= entry.payments.length) {
        return undefined;
      }
      
      // Get payment to be deleted
      const paymentToDelete = entry.payments[paymentIndex];
      
      // Delete the payment by removing it from the array
      const updatedPayments = [...entry.payments];
      updatedPayments.splice(paymentIndex, 1);
      
      // Recalculate received and pending amounts
      const newReceivedAmount = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
      const newPendingAmount = entry.totalAmount - newReceivedAmount;
      
      // Determine new payment status
      let newStatus: PaymentStatusType;
      if (newReceivedAmount === 0) {
        newStatus = PaymentStatus.PENDING;
      } else if (newReceivedAmount < entry.totalAmount) {
        newStatus = PaymentStatus.PARTIAL;
      } else {
        newStatus = PaymentStatus.FULL;
      }
      
      const oldStatus: PaymentStatusType = entry.status as PaymentStatusType;
      
      // Update the entry with new payments and amounts
      const [updateResult] = await db
        .update(entries)
        .set({
          payments: updatedPayments,
          receivedAmount: newReceivedAmount,
          pendingAmount: newPendingAmount,
          status: newStatus
        })
        .where(eq(entries.id, entryId))
        .returning();
      
      if (!updateResult) return undefined;
      
      // Log deletion as a CREDIT transaction (canceling the original DEBIT)
      await this.createTransactionLog({
        entryId: entryId,
        userId: deletedByUserId,
        username: user?.username || "system",
        description: `Deleted payment record of ₹${paymentToDelete.amount} from entry #${entryId}`,
        amount: paymentToDelete.amount,
        transactionType: TransactionType.CREDIT,
        details: paymentToDelete
      });
      
      // Also log status change if it happened
      if (oldStatus !== newStatus) {
        await this.createTransactionLog({
          entryId: entryId,
          userId: deletedByUserId,
          username: user?.username || "system",
          description: `Payment status changed from ${oldStatus} to ${newStatus}`,
          amount: 0,
          transactionType: TransactionType.UPDATE_PAYMENT,
          details: {
            oldStatus,
            newStatus
          }
        });
      }
      
      return updateResult;
    } catch (error) {
      console.error(`Error deleting payment for entry ${entryId}:`, error);
      return undefined;
    }
  }
  
  async recordPayment(entryId: number, payment: PaymentRecord, recordedByUserId: number): Promise<Entry | undefined> {
    try {
      // Get the entry to modify
      const entryResult = await db.select({
        entry: entries,
        user: users
      })
      .from(entries)
      .leftJoin(users, eq(entries.userId, users.id))
      .where(eq(entries.id, entryId));
      
      if (entryResult.length === 0) return undefined;
      
      const entry = entryResult[0].entry;
      const user = entryResult[0].user;
      
      // Ensure payments array exists
      const currentPayments = entry.payments || [];
      
      // Add the new payment
      const updatedPayments = [...currentPayments, payment];
      
      // Calculate new received and pending amounts
      const newReceivedAmount = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
      const newPendingAmount = entry.totalAmount - newReceivedAmount;
      
      // Determine payment status
      const oldStatus: PaymentStatusType = entry.status as PaymentStatusType;
      let newStatus: PaymentStatusType = entry.status as PaymentStatusType;
      
      if (newReceivedAmount === 0) {
        newStatus = PaymentStatus.PENDING;
      } else if (newReceivedAmount < entry.totalAmount) {
        newStatus = PaymentStatus.PARTIAL;
      } else {
        newStatus = PaymentStatus.FULL;
      }
      
      // Update the entry with the new payment and amounts
      const [updateResult] = await db
        .update(entries)
        .set({
          payments: updatedPayments,
          receivedAmount: newReceivedAmount,
          pendingAmount: newPendingAmount,
          status: newStatus
        })
        .where(eq(entries.id, entryId))
        .returning();
      
      if (!updateResult) return undefined;
      
      // Get user who recorded the payment
      const recordingUser = await this.getUser(recordedByUserId);
      
      // Log the payment as a DEBIT transaction - Ensuring TransactionType is specified
      try {
        await this.createTransactionLog({
          entryId: entryId,
          userId: recordedByUserId,
          username: recordingUser?.username || "system",
          description: `Payment of ₹${payment.amount} recorded by ${recordingUser?.username || "system"}`,
          amount: payment.amount,
          transactionType: TransactionType.DEBIT, // Explicitly setting the transaction type
          details: {
            date: payment.date,
            paymentMode: payment.mode,
            receiptNo: payment.receiptNo
          }
        });
      } catch (logError) {
        console.error("Error creating transaction log:", logError);
        // Continue execution even if logging fails
      }
      
      // Log status change if status has changed
      if (oldStatus !== newStatus) {
        await this.createTransactionLog({
          entryId: entryId,
          userId: recordedByUserId,
          username: user?.username || "system",
          description: `Payment status changed from ${oldStatus} to ${newStatus}`,
          amount: 0,
          transactionType: TransactionType.UPDATE_PAYMENT,
          details: {
            oldStatus,
            newStatus,
            payment
          }
        });
      }
      
      return updateResult;
    } catch (error) {
      console.error(`Error recording payment for entry ${entryId}:`, error);
      return undefined;
    }
  }

  // New methods for user detail functionality
  async getEntriesByUserId(userId: number): Promise<Entry[]> {
    return this.getUserEntries(userId);
  }

  async getAdvancePayments(): Promise<any[]> {
    try {
      // This is a placeholder - you'll need to implement based on your advance payments schema
      // For now, return empty array
      return [];
    } catch (error) {
      console.error("Error fetching advance payments:", error);
      return [];
    }
  }

  async getAdvancePaymentsByUserId(userId: number): Promise<any[]> {
    try {
      // This is a placeholder - you'll need to implement based on your advance payments schema
      // For now, return empty array
      return [];
    } catch (error) {
      console.error(`Error fetching advance payments for user ${userId}:`, error);
      return [];
    }
  }

  async getDravyaEntries(): Promise<any[]> {
    try {
      // This is a placeholder - you'll need to implement based on your dravya entries schema
      // For now, return empty array
      return [];
    } catch (error) {
      console.error("Error fetching dravya entries:", error);
      return [];
    }
  }

  async getDravyaEntriesByUserId(userId: number): Promise<any[]> {
    try {
      // This is a placeholder - you'll need to implement based on your dravya entries schema
      // For now, return empty array
      return [];
    } catch (error) {
      console.error(`Error fetching dravya entries for user ${userId}:`, error);
      return [];
    }
  }

  async calculateRemainingAdvancePayment(userId: number): Promise<number> {
    try {
      const { pool } = await import("./db");
      
      // Get total advance payments for the user
      const advanceResult = await pool.query(
        'SELECT COALESCE(SUM(amount), 0) as total_advance FROM advance_payments WHERE user_id = $1',
        [userId]
      );
      
      // Get total used advance payments (payments made using advance)
      const usedResult = await pool.query(
        'SELECT COALESCE(SUM(amount), 0) as total_used FROM advance_payment_usage WHERE user_id = $1',
        [userId]
      );
      
      const totalAdvance = parseInt(advanceResult.rows[0]?.total_advance || '0');
      const totalUsed = parseInt(usedResult.rows[0]?.total_used || '0');
      
      console.log(`[DEBUG] User ${userId} - Total Advance: ${totalAdvance}, Total Used: ${totalUsed}`);
      
      const remainingBalance = totalAdvance - totalUsed;
      
      console.log(`[DEBUG] User ${userId} - Calculated Balance: ${remainingBalance}`);
      
      // Return 0 if balance would be negative (user can't have negative advance balance)
      const finalBalance = Math.max(0, remainingBalance);
      console.log(`[DEBUG] User ${userId} - Final Balance: ${finalBalance}`);
      
      return finalBalance;
    } catch (error) {
      console.error(`Error calculating advance payment for user ${userId}:`, error);
      return 0;
    }
  }
}

// Initialize the database and storage
async function initializeDatabase() {
  // Database initialization can happen here if needed
  console.log("Database initialized");
}

export const storage = new DatabaseStorage();