#!/bin/bash

echo "🏛️  दान-दर्पण Local Setup Script"
echo "=================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js v18 or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version $NODE_VERSION is too old. Please install Node.js v18 or higher."
    exit 1
fi

# Check if PostgreSQL is installed
if ! command -v psql &> /dev/null; then
    echo "❌ PostgreSQL is not installed. Please install PostgreSQL v14 or higher."
    exit 1
fi

echo "✅ Prerequisites check passed"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Copy environment file if it doesn't exist
if [ ! -f .env ]; then
    cp .env.example .env
    echo "📝 Created .env file from template"
    echo "⚠️  Please edit .env file with your database credentials"
fi

# Create uploads directory
mkdir -p uploads
echo "📁 Created uploads directory"

# Database setup script already created
echo "🗄️  Database setup script ready (setup_database.sql)"


echo ""
echo "Next steps:"
echo "1. Start PostgreSQL: sudo service postgresql start"
echo "2. Run database setup: sudo -u postgres psql -f setup_database.sql"
echo "3. Edit .env file with your credentials"
echo "4. Push database schema: npm run db:push"
echo "5. Start application: npm run dev"
echo ""
echo "Access your application at: http://223.190.85.106:5000"