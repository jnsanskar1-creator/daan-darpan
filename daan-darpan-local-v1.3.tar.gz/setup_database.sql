-- दान-दर्पण Database Setup Script
-- Creates PostgreSQL database and user for local installation

-- Create user for the application
CREATE USER daan_user WITH PASSWORD 'daan_password';

-- Create database with correct ownership
CREATE DATABASE daan_darpan WITH OWNER daan_user ENCODING 'UTF8';

-- Grant necessary privileges
GRANT ALL PRIVILEGES ON DATABASE daan_darpan TO daan_user;

-- Connect to the database and grant schema privileges
\connect daan_darpan

-- Grant schema permissions
GRANT ALL ON SCHEMA public TO daan_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO daan_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO daan_user;

-- Set default privileges for future objects
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO daan_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO daan_user;

-- Success message
\echo 'Database daan_darpan and user daan_user created successfully!'
\echo 'You can now restore your backup data using the restore scripts.'