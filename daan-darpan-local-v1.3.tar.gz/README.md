# दान-दर्पण Local Installation Guide

## Prerequisites
- Node.js (v18 or higher)
- PostgreSQL (v14 or higher)
- Git

## Installation Steps

### 1. Extract and Setup
```bash
# Extract the ZIP file to your Desktop
cd ~/Desktop/daan-darpan-local

# Install dependencies
npm install
```

### 2. Database Setup
```bash
# Start PostgreSQL service
sudo service postgresql start

# Create database and user
sudo -u postgres psql
CREATE DATABASE daan_darpan;
CREATE USER daan_user WITH PASSWORD 'daan_password';
GRANT ALL PRIVILEGES ON DATABASE daan_darpan TO daan_user;
\q
```

### 3. Environment Configuration
```bash
# Copy environment file
cp .env.example .env

# Edit .env file with your database credentials
nano .env
```

### 4. Database Setup

Choose one option:

**Option A: Fresh Installation with Sample Data**
```bash
# Push database schema
npm run db:push

# Create sample data for testing
./scripts/create-sample-data.sh
```

**Option B: Restore from Production Backup**
```bash
# Place your backup file in database-backups/
# Then restore it
./scripts/restore-database.sh database-backups/your-backup.sql.gz
```

### 5. Start Application
```bash
# Development mode
npm run dev

# Production mode
npm run build
npm start
```

## Access URLs

- **Local Network**: http://223.190.85.106:5000
- **Localhost**: http://localhost:5000

## Default Admin Credentials

- Username: `admin`
- Password: `admin123`

## Important Notes

1. **Security**: Change default admin password after first login
2. **Backup**: Regular database backups are recommended
3. **Updates**: Check for updates regularly
4. **Support**: Refer to operator-help-guide.md for detailed usage instructions

## Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Kill process on port 5000
   sudo lsof -t -i:5000 | xargs kill -9
   ```

2. **Database Connection Error**
   - Verify PostgreSQL is running
   - Check database credentials in .env
   - Ensure database exists

3. **Permission Issues**
   ```bash
   # Fix npm permissions
   sudo chown -R $(whoami) ~/.npm
   ```

## File Structure
```
daan-darpan-local/
├── client/              # Frontend React application
├── server/              # Backend Express server
├── shared/              # Shared TypeScript types
├── uploads/             # File uploads directory
├── package.json         # Dependencies
├── .env.example         # Environment template
└── README.md           # This file
```