#!/bin/bash

# दान-दर्पण Sample Data Creator
# Creates sample data for testing and demonstration

set -e

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

echo "🏛️  Creating दान-दर्पण Sample Data..."
echo ""

# Create sample data SQL
cat > /tmp/sample_data.sql << 'EOF'
-- Sample Data for दान-दर्पण Application

-- Insert sample users with different roles
INSERT INTO users (id, username, password_hash, role, name, mobile, address, serial_number) VALUES
(1, 'admin', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Administrator', '9876543210', 'Temple Office, Shivnagar', 1),
(2, 'operator1', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'operator', 'Operator One', '9876543211', 'Shivnagar, Jabalpur', 2),
(3, 'viewer1', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'viewer', 'Viewer One', '9876543212', 'Shivnagar, Jabalpur', 3),
(4, 'ramesh_ji', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'viewer', 'Ramesh Kumar Jain', '9876543213', 'Gandhi Nagar, Jabalpur', 4),
(5, 'sunita_devi', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'viewer', 'Sunita Devi Jain', '9876543214', 'Civil Lines, Jabalpur', 5)
ON CONFLICT (id) DO UPDATE SET
  username = EXCLUDED.username,
  name = EXCLUDED.name,
  mobile = EXCLUDED.mobile,
  address = EXCLUDED.address;

-- Set corpus value
INSERT INTO corpus_settings (id, corpus_value) VALUES (1, 13908400) -- ₹139,084 in paisa
ON CONFLICT (id) DO UPDATE SET corpus_value = EXCLUDED.corpus_value;

-- Insert sample boli entries
INSERT INTO boli_entries (user_id, amount, auction_date, entry_date, payment_status, received_amount, pending_amount, description, created_by) VALUES
(4, 500000, '2025-07-01', '2025-07-01', 'completed', 500000, 0, 'Monthly Boli - Ramesh Ji', 1),
(5, 300000, '2025-07-02', '2025-07-02', 'partial', 200000, 100000, 'Special Occasion Boli', 1),
(4, 150000, '2025-07-15', '2025-07-15', 'pending', 0, 150000, 'Festival Boli', 2),
(5, 250000, '2025-08-01', '2025-08-01', 'completed', 250000, 0, 'Puja Boli', 2);

-- Insert sample advance payments
INSERT INTO advance_payments (user_id, amount, payment_date, payment_mode, description, created_by) VALUES
(4, 100000, '2025-06-15', 'cash', 'Advance for upcoming pujas', 1),
(5, 50000, '2025-06-20', 'upi', 'General advance payment', 1);

-- Insert sample expense entries
INSERT INTO expense_entries (description, amount, expense_date, payment_mode, created_by, firm_name, bill_number, line_item, quantity, reason, approved_by, paid_by) VALUES
('Prasad Materials', 250000, '2025-07-01', 'cash', 1, 'Krishna Stores', 'B001', 'Mishri, Dry Fruits', 5, 'Monthly prasad preparation', 'Pandit Ji', 'Treasurer'),
('Electricity Bill', 180000, '2025-07-05', 'upi', 1, 'MP Electricity Board', 'EB202507', 'Temple electricity', 1, 'Monthly electricity charges', 'Secretary', 'Operator'),
('Cleaning Supplies', 85000, '2025-07-10', 'cash', 1, 'Clean India Suppliers', 'C789', 'Phenyl, Detergent, Brooms', 10, 'Monthly cleaning supplies', 'Caretaker', 'Operator');

-- Insert sample dravya entries (separate from main system)
INSERT INTO dravya_entries (user_id, amount, entry_date, description, created_by) VALUES
(4, 25000, '2025-07-01', 'Monthly Dravya Donation', 1),
(5, 15000, '2025-07-15', 'Special Puja Dravya', 2);

-- Insert sample previous outstanding records
INSERT INTO previous_outstanding_records (user_id, total_outstanding_amount, received_amount, pending_amount, description, created_by) VALUES
(4, 75000, 50000, 25000, 'Previous year pending amount', 1),
(5, 30000, 30000, 0, 'Old temple contribution', 1);

-- Insert sample boli payments
INSERT INTO boli_payments (boli_entry_id, amount, payment_date, payment_mode, receipt_number, description, created_by) VALUES
(1, 500000, '2025-07-01', 'cash', 'SPDJMSJ000001', 'Full payment for monthly boli', 1),
(2, 200000, '2025-07-02', 'upi', 'SPDJMSJ000002', 'Partial payment', 1),
(4, 250000, '2025-08-01', 'cash', 'SPDJMSJ000003', 'Festival boli payment', 2);

-- Update receipt counter
INSERT INTO receipt_counter (id, last_receipt_number) VALUES (1, 3)
ON CONFLICT (id) DO UPDATE SET last_receipt_number = EXCLUDED.last_receipt_number;

-- Insert transaction logs for audit trail
INSERT INTO transaction_logs (entry_type, entry_id, action, old_values, new_values, user_id, timestamp) VALUES
('boli_entry', 1, 'create', '{}', '{"amount": 500000, "payment_status": "completed"}', 1, '2025-07-01 10:00:00'),
('boli_payment', 1, 'create', '{}', '{"amount": 500000, "payment_mode": "cash"}', 1, '2025-07-01 10:30:00'),
('advance_payment', 1, 'create', '{}', '{"amount": 100000, "payment_mode": "cash"}', 1, '2025-06-15 14:00:00');

EOF

# Execute sample data creation
echo "📊 Inserting sample data..."

# Default values
DB_NAME=${PGDATABASE:-"daan_darpan"}
DB_USER=${PGUSER:-"daan_user"}
DB_HOST=${PGHOST:-"localhost"}
DB_PORT=${PGPORT:-"5432"}

PGPASSWORD="$PGPASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
    -v ON_ERROR_STOP=1 \
    -f /tmp/sample_data.sql

# Clean up
rm /tmp/sample_data.sql

if [ $? -eq 0 ]; then
    echo "✅ Sample data created successfully!"
    echo ""
    echo "🔑 Login Credentials:"
    echo "   Admin:     admin / admin123"
    echo "   Operator:  operator1 / admin123"
    echo "   Viewer:    viewer1 / admin123"
    echo "   User:      ramesh_ji / admin123"
    echo "   User:      sunita_devi / admin123"
    echo ""
    echo "📊 Sample Data Includes:"
    echo "   • 5 users with different roles"
    echo "   • 4 boli entries with various payment statuses"
    echo "   • 2 advance payments"
    echo "   • 3 expense entries"
    echo "   • 2 dravya entries"
    echo "   • Outstanding records"
    echo "   • Payment history"
    echo "   • Corpus setting: ₹139,084"
else
    echo "❌ Sample data creation failed!"
    exit 1
fi