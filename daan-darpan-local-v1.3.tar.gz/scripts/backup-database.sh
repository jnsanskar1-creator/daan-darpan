#!/bin/bash

# दान-दर्पण Database Backup Script
# Creates a complete backup of the application database

set -e

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

# Default values
DB_NAME=${PGDATABASE:-"daan_darpan"}
DB_USER=${PGUSER:-"daan_user"}
DB_HOST=${PGHOST:-"localhost"}
DB_PORT=${PGPORT:-"5432"}

# Create backup directory
BACKUP_DIR="database-backups"
mkdir -p "$BACKUP_DIR"

# Generate timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$BACKUP_DIR/daan_darpan_backup_$TIMESTAMP.sql"

echo "🏛️  Creating दान-दर्पण Database Backup..."
echo "Database: $DB_NAME"
echo "User: $DB_USER"
echo "Host: $DB_HOST:$DB_PORT"
echo "Backup file: $BACKUP_FILE"
echo ""

# Create database backup
PGPASSWORD="$PGPASSWORD" pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
    --verbose \
    --clean \
    --if-exists \
    --create \
    --column-inserts \
    --disable-triggers \
    > "$BACKUP_FILE"

if [ $? -eq 0 ]; then
    echo "✅ Database backup created successfully!"
    echo "📁 File: $BACKUP_FILE"
    echo "📊 Size: $(du -h "$BACKUP_FILE" | cut -f1)"
    
    # Create latest backup symlink
    ln -sf "$(basename "$BACKUP_FILE")" "$BACKUP_DIR/latest_backup.sql"
    echo "🔗 Latest backup linked as: $BACKUP_DIR/latest_backup.sql"
    
    # Compress backup
    gzip "$BACKUP_FILE"
    echo "🗜️  Backup compressed: $BACKUP_FILE.gz"
    
    # Update latest compressed backup symlink
    ln -sf "$(basename "$BACKUP_FILE.gz")" "$BACKUP_DIR/latest_backup.sql.gz"
    
    echo ""
    echo "📋 To restore this backup, use:"
    echo "   ./scripts/restore-database.sh $BACKUP_FILE.gz"
    
else
    echo "❌ Database backup failed!"
    exit 1
fi