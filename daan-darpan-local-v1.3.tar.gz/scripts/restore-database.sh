#!/bin/bash

# दान-दर्पण Database Restore Script
# Restores database from backup file

set -e

# Check if backup file is provided
if [ $# -eq 0 ]; then
    echo "❌ Usage: $0 <backup_file>"
    echo "   Example: $0 database-backups/daan_darpan_backup_20250817_120000.sql.gz"
    echo "   Or use: $0 latest  (to restore latest backup)"
    exit 1
fi

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

# Default values
DB_NAME=${PGDATABASE:-"daan_darpan"}
DB_USER=${PGUSER:-"daan_user"}
DB_HOST=${PGHOST:-"localhost"}
DB_PORT=${PGPORT:-"5432"}

# Determine backup file
if [ "$1" = "latest" ]; then
    BACKUP_FILE="database-backups/latest_backup.sql.gz"
    if [ ! -f "$BACKUP_FILE" ]; then
        BACKUP_FILE="database-backups/latest_backup.sql"
    fi
else
    BACKUP_FILE="$1"
fi

# Check if backup file exists
if [ ! -f "$BACKUP_FILE" ]; then
    echo "❌ Backup file not found: $BACKUP_FILE"
    exit 1
fi

echo "🏛️  Restoring दान-दर्पण Database..."
echo "Database: $DB_NAME"
echo "User: $DB_USER"
echo "Host: $DB_HOST:$DB_PORT"
echo "Backup file: $BACKUP_FILE"
echo ""

# Confirm before proceeding
read -p "⚠️  This will replace ALL data in database '$DB_NAME'. Continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Restore cancelled."
    exit 1
fi

# Create temporary file for decompressed backup
TEMP_FILE="/tmp/daan_darpan_restore_$$.sql"

# Decompress if needed
if [[ "$BACKUP_FILE" == *.gz ]]; then
    echo "📦 Decompressing backup file..."
    gunzip -c "$BACKUP_FILE" > "$TEMP_FILE"
    RESTORE_FILE="$TEMP_FILE"
else
    RESTORE_FILE="$BACKUP_FILE"
fi

# Stop application if running
echo "🛑 Stopping application..."
pkill -f "tsx server/index.ts" || true
pkill -f "node dist/index.js" || true
sleep 2

# Restore database
echo "🔄 Restoring database..."
PGPASSWORD="$PGPASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres \
    -v ON_ERROR_STOP=1 \
    -f "$RESTORE_FILE"

# Clean up temporary file
if [ -f "$TEMP_FILE" ]; then
    rm "$TEMP_FILE"
fi

if [ $? -eq 0 ]; then
    echo "✅ Database restored successfully!"
    echo ""
    echo "🚀 You can now start the application:"
    echo "   npm run dev    (development mode)"
    echo "   npm start      (production mode)"
else
    echo "❌ Database restore failed!"
    exit 1
fi